/*
 * File: policy_step.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "policy_step.h"
#include "PolicySystem.h"
#include "handle.h"
#include "loadRLPolicy.h"
#include "policy_step_data.h"
#include "policy_step_initialize.h"
#include "policy_step_internal_types.h"

/* Variable Definitions */
static rl_codegen_model_DLNetworkModel gobj_1;

static c_rl_codegen_policy_rlDetermini actor;

static boolean_T actor_not_empty;

/* Function Definitions */
/*
 * Reinforcement Learning Toolbox
 *  Generated on: 18-Aug-2025 20:25:53
 *
 * Arguments    : const float observation1[4]
 * Return Type  : double
 */
double policy_step(const float observation1[4])
{
  if (!isInitialized_policy_step) {
    policy_step_initialize();
  }
  if (!actor_not_empty) {
    loadRLPolicy(&gobj_1, &actor);
    actor_not_empty = true;
  }
  /*  evaluate the policy */
  return PolicySystem_getAction(&actor, observation1);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void policy_step_delete(void)
{
  b_handle_matlabCodegenDestructo(&actor);
  handle_matlabCodegenDestructor(&gobj_1);
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void policy_step_init(void)
{
  actor_not_empty = false;
}

/*
 * Arguments    : void
 * Return Type  : void
 */
void policy_step_new(void)
{
  gobj_1.matlabCodegenIsDeleted = true;
  actor.matlabCodegenIsDeleted = true;
}

/*
 * File trailer for policy_step.c
 *
 * [EOF]
 */
