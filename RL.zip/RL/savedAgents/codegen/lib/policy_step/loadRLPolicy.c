/*
 * File: loadRLPolicy.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "loadRLPolicy.h"
#include "policy_step_internal_types.h"

/* Function Definitions */
/*
 * Arguments    : rl_codegen_model_DLNetworkModel *iobj_0
 *                c_rl_codegen_policy_rlDetermini *iobj_1
 * Return Type  : c_rl_codegen_policy_rlDetermini *
 */
c_rl_codegen_policy_rlDetermini *
loadRLPolicy(rl_codegen_model_DLNetworkModel *iobj_0,
             c_rl_codegen_policy_rlDetermini *iobj_1)
{
  c_rl_codegen_policy_rlDetermini *varargout_1;
  iobj_0->isInitialized = 0;
  iobj_0->matlabCodegenIsDeleted = false;
  iobj_0->isSetupComplete = false;
  iobj_0->isInitialized = 1;
  iobj_0->isSetupComplete = true;
  iobj_1->isInitialized = 0;
  varargout_1 = iobj_1;
  iobj_1->ActionBounder_.UpperLimits_[0] = 9.42477796076938;
  iobj_1->ActionBounder_.LowerLimits_[0] = -9.42477796076938;
  iobj_1->Model_ = iobj_0;
  iobj_1->matlabCodegenIsDeleted = false;
  iobj_1->isSetupComplete = false;
  iobj_1->isInitialized = 1;
  iobj_1->isSetupComplete = true;
  return varargout_1;
}

/*
 * File trailer for loadRLPolicy.c
 *
 * [EOF]
 */
