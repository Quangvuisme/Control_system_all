%% SET UP ENVIRONMENT
% Speedup options
useFastRestart = true;
useGPU = true;      % Cart-Pole không cần GPU
useParallel = true; % Không cần parallel training

% Create the observation info
numObs = 4; % Cart-Pole có 4 đầu vào: [x, x_dot, theta, theta_dot]
observationInfo = rlNumericSpec([numObs 1]);
observationInfo.Name = 'observations';

% Create the action info
numAct = 1; % Cart-Pole có 1 đầu ra: lực tác động lên xe đẩy
actionInfo = rlNumericSpec([numAct 1], 'LowerLimit', -pi*3, 'UpperLimit', pi*3);
actionInfo.Name = 'cart_force';

% Environment
mdl = 'cartPoleRL'; % Mô hình Simulink cho Cart-Pole
load_system(mdl);
blk = [mdl, '/RL Agent'];
env = rlSimulinkEnv(mdl, blk, observationInfo, actionInfo);
env.ResetFcn = @(in)cartPoleResetFcn(in);

if ~useFastRestart
    env.UseFastRestart = 'on';
end
obsInfo = getObservationInfo(env);
actInfo = getActionInfo(env);
%% Create DDPG Agent
initOpts = rlAgentInitializationOptions(NumHiddenUnit=200);

criticOptions = rlOptimizerOptions( ...
    LearnRate=5e-03, ...
    GradientThreshold=1);
actorOptions = rlOptimizerOptions( ...
    LearnRate=5e-03, ...
    GradientThreshold=1);
agentOptions = rlDDPGAgentOptions(...
    SampleTime=Ts,...
    ActorOptimizerOptions=actorOptions,...
    CriticOptimizerOptions=criticOptions,...
    ExperienceBufferLength=1e5,...
    TargetSmoothFactor=5e-3,...
    MaxMiniBatchPerEpoch=200);

agentOptions.NoiseOptions.StandardDeviation = 1.0/sqrt(Ts);
agentOptions.NoiseOptions.MeanAttractionConstant = 0.1/Ts;

rng(0,"twister");
agent = rlDDPGAgent(obsInfo,actInfo,initOpts,agentOptions);

%% CREATE AND TRAIN AGENT
% training options
maxepisodes = 2000;
maxsteps = ceil(Tf/Ts);
trainingOptions = rlTrainingOptions(...
    MaxEpisodes=maxepisodes,...
    MaxStepsPerEpisode=maxsteps,...
    ScoreAveragingWindowLength=5,...
    Verbose=false,...
    Plots="training-progress",...
    StopTrainingCriteria="EvaluationStatistic",...
    StopTrainingValue=-100);

if useParallel
    trainingOptions.Parallelization = 'async';
    trainingOptions.ParallelizationOptions.Mode = 'async';
    trainingOptions.ParallelizationOptions.WorkerRandomSeeds = -1;
    trainingOptions.ParallelizationOptions.StepsUntilDataIsSent = 64;
end

% agent evaluation
evl = rlEvaluator(NumEpisodes=1,EvaluationFrequency=10);

rng(0,"twister");
%%
doTraining = true;
if doTraining    
    % Train the agent.
    trainingStats = train(agent,env,trainingOptions,Evaluator=evl);
else
    % Load the pretrained agent for the example.
    load("SimscapeCartPoleDDPG.mat","agent")
end
%% SAVE AGENT
reset(agent); % Clears the experience buffer
curDir = pwd;
saveDir = 'savedAgents';
if ~exist(saveDir, 'dir')
    mkdir(saveDir);
end
cd(saveDir);
save(['trainedAgent_CartPole_' datestr(now, 'mm_DD_YYYY_HHMM')], 'agent');
save(['trainingResults_CartPole_' datestr(now, 'mm_DD_YYYY_HHMM')], 'trainingStats');
cd(curDir);

