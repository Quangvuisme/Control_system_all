function action1 = policy_step(observation1)
%#codegen

% Reinforcement Learning Toolbox
% Generated on: 18-Aug-2025 20:25:53

persistent actor;
if isempty(actor)
	actor = coder.loadRLPolicy("agentForCodegen2.mat");
end
% evaluate the policy
action1 = getAction(actor,observation1);