/*
 * File: elementwiseOperation.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "elementwiseOperation.h"

/* Function Definitions */
/*
 * Arguments    : float X
 * Return Type  : float
 */
float lambdaForColumnMajorGeneric(float X)
{
  return 9.42477798F * X;
}

/*
 * File trailer for elementwiseOperation.c
 *
 * [EOF]
 */
