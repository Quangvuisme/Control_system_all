/*
 * File: handle.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef HANDLE_H
#define HANDLE_H

/* Include Files */
#include "policy_step_internal_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void b_handle_matlabCodegenDestructo(c_rl_codegen_policy_rlDetermini *obj);

void handle_matlabCodegenDestructor(rl_codegen_model_DLNetworkModel *obj);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for handle.h
 *
 * [EOF]
 */
