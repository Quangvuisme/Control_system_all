/*
 * File: unaryElementwise.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "unaryElementwise.h"
#include "omp.h"
#include <xmmintrin.h>

/* Function Declarations */
static void elementwise_relu(const float *inputTensor, float *outputTensor);

/* Function Definitions */
/*
 * Arguments    : const float *inputTensor
 *                float *outputTensor
 * Return Type  : void
 */
static void elementwise_relu(const float *inputTensor, float *outputTensor)
{
  __m128 reg_0;
  __m128 reluZero;
  int baseIdx;
  int simdBlockIdx;
  reluZero = _mm_set1_ps(0.0F);
#pragma omp parallel for num_threads(omp_get_max_threads()) private(baseIdx,   \
                                                                        reg_0)

  for (simdBlockIdx = 0; simdBlockIdx < 50; simdBlockIdx++) {
    baseIdx = simdBlockIdx << 2;
    reg_0 = _mm_loadu_ps(&inputTensor[baseIdx]);
    reg_0 = _mm_max_ps(reg_0, reluZero);
    _mm_storeu_ps(&outputTensor[baseIdx], reg_0);
  }
}

/*
 * Arguments    : const float X[200]
 *                float Z[200]
 * Return Type  : void
 */
void unaryElementwise(const float X[200], float Z[200])
{
  elementwise_relu(&X[0], &Z[0]);
}

/*
 * File trailer for unaryElementwise.c
 *
 * [EOF]
 */
