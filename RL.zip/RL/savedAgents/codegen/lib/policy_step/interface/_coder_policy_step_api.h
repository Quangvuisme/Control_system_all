/*
 * File: _coder_policy_step_api.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef _CODER_POLICY_STEP_API_H
#define _CODER_POLICY_STEP_API_H

/* Include Files */
#include "emlrt.h"
#include "mex.h"
#include "tmwtypes.h"
#include <string.h>

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
real_T policy_step(real32_T observation1[4]);

void policy_step_api(const mxArray *prhs, const mxArray **plhs);

void policy_step_atexit(void);

void policy_step_initialize(void);

void policy_step_terminate(void);

void policy_step_xil_shutdown(void);

void policy_step_xil_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_policy_step_api.h
 *
 * [EOF]
 */
