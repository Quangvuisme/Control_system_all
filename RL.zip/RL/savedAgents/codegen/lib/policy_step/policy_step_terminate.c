/*
 * File: policy_step_terminate.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "policy_step_terminate.h"
#include "policy_step.h"
#include "policy_step_data.h"
#include "omp.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void policy_step_terminate(void)
{
  policy_step_delete();
  omp_destroy_nest_lock(&policy_step_nestLockGlobal);
  isInitialized_policy_step = false;
}

/*
 * File trailer for policy_step_terminate.c
 *
 * [EOF]
 */
