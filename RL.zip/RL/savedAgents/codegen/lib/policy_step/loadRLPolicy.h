/*
 * File: loadRLPolicy.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef LOADRLPOLICY_H
#define LOADRLPOLICY_H

/* Include Files */
#include "policy_step_internal_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
c_rl_codegen_policy_rlDetermini *
loadRLPolicy(rl_codegen_model_DLNetworkModel *iobj_0,
             c_rl_codegen_policy_rlDetermini *iobj_1);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for loadRLPolicy.h
 *
 * [EOF]
 */
