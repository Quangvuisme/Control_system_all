//
// File: derivatives_state_types.h
//
// Code generated for Simulink model 'derivatives_state'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Dec 31 20:07:34 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Emulation hardware selection:
//    Differs from embedded hardware (Custom Processor->MATLAB Host Computer)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef derivatives_state_types_h_
#define derivatives_state_types_h_
#endif                                 // derivatives_state_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
