/*
 * File: policy_step_initialize.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef POLICY_STEP_INITIALIZE_H
#define POLICY_STEP_INITIALIZE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void policy_step_initialize(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for policy_step_initialize.h
 *
 * [EOF]
 */
