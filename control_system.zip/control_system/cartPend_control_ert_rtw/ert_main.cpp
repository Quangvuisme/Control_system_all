//
// File: ert_main.cpp
//
// Code generated for Simulink model 'cartPend_control'.
//
// Model version                  : 1.3
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Thu Mar 20 15:07:42 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include <stdio.h>
#include <stdlib.h>
#include "cartPend_control.h"
#include "cartPend_control_private.h"
#include "rtwtypes.h"
#include "limits.h"
#include "linuxinitialize.h"
#define UNUSED(x)                      x = x

static cartPend_control cartPend_control_Obj;// Instance of model class

#define NAMELEN                        16

void exitFcn(int sig);
void *terminateTask(void *arg);
void *baseRateTask(void *arg);
void *subrateTask(void *arg);
void *schedulerTask(void *arg);
void *SOCB_RateCounterTask(void);
volatile boolean_T stopRequested = false;
volatile boolean_T runModel = true;
sem_t stopSem;
sem_t baserateTaskSem;
sem_t SOCB_RateSchedulerSem;
int SOCB_RateTriggerCounter[1] = { 0 };

pthread_t baseRateThread;
pthread_t schedulerThread;
pthread_t SOCB_RateSchedulerThread;
void *threadJoinStatus;
int terminatingmodel = 0;
int coreAffinityBaseRate;
int coreAffinity[0];

#define SOCB_RATE_TASK_WAITING         0
#define SOCB_RATE_TASK_READY           1
#define SOCB_RATE_TASK_RUNNING         2

uint16_T SOCB_RateTaskState[1] = { SOCB_RATE_TASK_WAITING };

uint16_T SOCB_DropOverranRate[1] = {
  0,
};

uint16_T SOCB_RateTimerEventCounter[1] = {
  1,
};

uint16_T SOCB_RateTimerEventCounterTrigVal[1] = {
  1,
};

void *SOCB_RateCounterFcn(void)
{
  SOCB_RateTriggerCounter[0]++;
  if ((SOCB_DropOverranRate[0]) && (SOCB_RateTaskState[0])) {
    SOCB_RateTriggerCounter[0]--;
  } else if (SOCB_RateTriggerCounter[0] > 2) {
    SOCB_RateTriggerCounter[0]--;
  }

  sem_post(&SOCB_RateSchedulerSem);
}

void *schedulerTask(void *arg)
{
  while (runModel) {
    sem_wait(&SOCB_RateSchedulerSem);
    if ((SOCB_RateTriggerCounter[0] > 0) && (SOCB_RateTaskState[0] !=
         SOCB_RATE_TASK_RUNNING)) {
      SOCB_RateTaskState[0] = SOCB_RATE_TASK_RUNNING;
      SOCB_RateTriggerCounter[0]--;
      sem_post(&baserateTaskSem);
    }
  }
}

void *baseRateTask(void *arg)
{
  runModel = (cartPend_control_Obj.getRTM()->getErrorStatus() == (NULL));
  while (runModel) {
    sem_wait(&baserateTaskSem);
    cartPend_control_Obj.step();

    // Get model outputs here
    stopRequested = !((cartPend_control_Obj.getRTM()->getErrorStatus() == (NULL)));
    runModel = !stopRequested;
    SOCB_RateTaskState[0] = SOCB_RATE_TASK_WAITING;
    sem_post(&SOCB_RateSchedulerSem);
  }

  runModel = 0;
  terminateTask(arg);
  pthread_exit((void *)0);
  return NULL;
}

void exitFcn(int sig)
{
  UNUSED(sig);
  cartPend_control_Obj.getRTM()->setErrorStatus("stopping the model");
}

void *terminateTask(void *arg)
{
  UNUSED(arg);
  terminatingmodel = 1;

  {
    runModel = 0;
  }

  // Terminate model
  cartPend_control_Obj.terminate();
  sem_post(&stopSem);
  return NULL;
}

int main(int argc, char **argv)
{
  UNUSED(argc);
  UNUSED(argv);
  coreAffinityBaseRate = 0;
  cartPend_control_Obj.getRTM()->setErrorStatus(0);

  // Initialize model
  cartPend_control_Obj.initialize();

  // Call RTOS Initialization function
  myRTOSInit(0.2, 0);

  // Wait for stop semaphore
  sem_wait(&stopSem);

#if (MW_NUMBER_TIMER_DRIVEN_TASKS > 0)

  {
    int i;
    for (i=0; i < MW_NUMBER_TIMER_DRIVEN_TASKS; i++) {
      CHECK_STATUS(sem_destroy(&timerTaskSem[i]), 0, "sem_destroy");
    }
  }

#endif

  CHECK_STATUS(sem_destroy(&SOCB_RateSchedulerSem), 0, "sem_destroy");
  return 0;
}

//
// File trailer for generated code.
//
// [EOF]
//
