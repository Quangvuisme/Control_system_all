/*
 * File: callPredict.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "callPredict.h"
#include "addBiasApplyActivation.h"
#include "elementwiseOperation.h"
#include "elementwiseOperationInPlace.h"
#include "unaryElementwise.h"
#include "omp.h"
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xmmintrin.h>

/* Function Declarations */
static char *computeFilePathUsingEnvVariable(const char *unresolvedFilePath);

static int div_nde_s32_floor(int numerator);

static int div_s32_floor(int numerator, int denominator);

static char *getCustomUserDataPathEnvVar(const char *unresolvedFilePath);

static int getPositionOfLastFileSeparator(const char *filePath);

static char *getRelativePathToParentFolder(const char *filePath);

static char *getResolvedFilePath(const char *unresolvedFilePath);

static void macroKernel1(int M, int K, int N, const float *A, int LDA,
                         const float *B, int LDB, float *C, int LDC);

static void matrixMultiply1(int M, int K, int N, int blockSizeM, int blockSizeK,
                            int blockSizeN, const float *A, const float *B,
                            float *C);

static void microKernel11(int K, const float *A, int LDA, const float *B,
                          float *C);

static void microKernel12(int K, const float *A, int LDA, const float *B,
                          float *C);

static void microKernel13(int K, const float *A, int LDA, const float *B,
                          float *C);

static void readDnnConstants(float *inputBufferPtr,
                             const char *unresolvedFilePath,
                             int numElementsToRead);

static char *resolveBinaryFilePath(const char *unresolvedFilePath);

static char *sanitizeFilePathForHSP(const char *unSanitizedFilePath);

static void stringConcat(char *destinationString, const char *sourceString,
                         size_t destBufferSize);

/* Function Definitions */
/*
 * Arguments    : const char *unresolvedFilePath
 * Return Type  : char *
 */
static char *computeFilePathUsingEnvVariable(const char *unresolvedFilePath)
{
  char *resolvedFilePath;
  char *stringDuplicate;
  size_t filePathLen;
  size_t sizeOfChar;
  filePathLen = strlen((char *)unresolvedFilePath) + 1;
  sizeOfChar = 1;
  stringDuplicate = (char *)calloc(filePathLen, sizeOfChar);
  stringConcat(stringDuplicate, unresolvedFilePath, filePathLen);
#if defined(MW_RUNTIME_DL_DATA_PATH) != 0
  extern char *mwGetRuntimeDLDataPath(const char *);
  resolvedFilePath = mwGetRuntimeDLDataPath((char *)unresolvedFilePath);
#elif defined(MW_DL_DATA_PATH) != 0
  resolvedFilePath = resolveBinaryFilePath(unresolvedFilePath);
#else
  char *coderDataPath;
  coderDataPath = getenv("CODER_DATA_PATH");
  if (coderDataPath != NULL) {
    resolvedFilePath = resolveBinaryFilePath(unresolvedFilePath);
  } else {
    resolvedFilePath = stringDuplicate;
  }
#endif
  return resolvedFilePath;
}

/*
 * Arguments    : int numerator
 * Return Type  : int
 */
static int div_nde_s32_floor(int numerator)
{
  int quotient;
  if ((numerator < 0) && (numerator % 28 != 0)) {
    quotient = -1;
  } else {
    quotient = 0;
  }
  quotient += numerator / 28;
  return quotient;
}

/*
 * Arguments    : int numerator
 *                int denominator
 * Return Type  : int
 */
static int div_s32_floor(int numerator, int denominator)
{
  int quotient;
  if (denominator == 0) {
    if (numerator >= 0) {
      quotient = MAX_int32_T;
    } else {
      quotient = MIN_int32_T;
    }
  } else {
    unsigned int absDenominator;
    unsigned int absNumerator;
    unsigned int tempAbsQuotient;
    boolean_T quotientNeedsNegation;
    if (numerator < 0) {
      absNumerator = ~(unsigned int)numerator + 1U;
    } else {
      absNumerator = (unsigned int)numerator;
    }
    if (denominator < 0) {
      absDenominator = ~(unsigned int)denominator + 1U;
    } else {
      absDenominator = (unsigned int)denominator;
    }
    quotientNeedsNegation = ((numerator < 0) != (denominator < 0));
    tempAbsQuotient = absNumerator / absDenominator;
    if (quotientNeedsNegation) {
      absNumerator %= absDenominator;
      if (absNumerator > 0U) {
        tempAbsQuotient++;
      }
      quotient = -(int)tempAbsQuotient;
    } else {
      quotient = (int)tempAbsQuotient;
    }
  }
  return quotient;
}

/*
 * Arguments    : const char *unresolvedFilePath
 * Return Type  : char *
 */
static char *getCustomUserDataPathEnvVar(const char *unresolvedFilePath)
{
  const char *fileName;
  char *coderDataPath;
  char *resolvedFilePath;
  coderDataPath = getenv("CODER_DATA_PATH");
  if (coderDataPath != NULL) {
    int posOfLastPathSeparator;
    size_t filePathLength;
    size_t sizeOfChar;
    posOfLastPathSeparator = getPositionOfLastFileSeparator(unresolvedFilePath);
    fileName = &unresolvedFilePath[posOfLastPathSeparator];
    filePathLength = (strlen(coderDataPath) + strlen((char *)fileName)) + 1;
    sizeOfChar = 1;
    resolvedFilePath = (char *)calloc(filePathLength, sizeOfChar);
    stringConcat(resolvedFilePath, coderDataPath, filePathLength);
    stringConcat(resolvedFilePath, fileName, filePathLength);
  } else {
    resolvedFilePath = NULL;
  }
  return resolvedFilePath;
}

/*
 * Arguments    : const char *filePath
 * Return Type  : int
 */
static int getPositionOfLastFileSeparator(const char *filePath)
{
  int lastPathSeparatorUnix;
  int posOfLastPathSeparator;
  const char *ptrToLastPathSeparator;
  lastPathSeparatorUnix = '/';
  ptrToLastPathSeparator = strrchr((char *)filePath, lastPathSeparatorUnix);
  if (ptrToLastPathSeparator != NULL) {
    posOfLastPathSeparator = (int)(ptrToLastPathSeparator - filePath);
  } else {
    int lastPathSeparatorWindows;
    lastPathSeparatorWindows = '\\';
    ptrToLastPathSeparator =
        strrchr((char *)filePath, lastPathSeparatorWindows);
    if (ptrToLastPathSeparator != NULL) {
      posOfLastPathSeparator = (int)(ptrToLastPathSeparator - filePath);
    } else {
      posOfLastPathSeparator = -1;
    }
  }
  return posOfLastPathSeparator;
}

/*
 * Arguments    : const char *filePath
 * Return Type  : char *
 */
static char *getRelativePathToParentFolder(const char *filePath)
{
  int posOfLastPathSeparator;
  const char *fileName;
  const char *parentDir;
  char *resolvedFilePath;
  size_t filePathLength;
  size_t sizeOfChar;
  parentDir = "..";
  posOfLastPathSeparator = getPositionOfLastFileSeparator(filePath);
  fileName = &filePath[posOfLastPathSeparator];
  filePathLength = (strlen((char *)parentDir) + strlen((char *)fileName)) + 1;
  sizeOfChar = 1;
  resolvedFilePath = (char *)calloc(filePathLength, sizeOfChar);
  stringConcat(resolvedFilePath, parentDir, filePathLength);
  stringConcat(resolvedFilePath, fileName, filePathLength);
  return resolvedFilePath;
}

/*
 * Arguments    : const char *unresolvedFilePath
 * Return Type  : char *
 */
static char *getResolvedFilePath(const char *unresolvedFilePath)
{
  const char *fileOpenMode;
  char *computedPathUsingEnvVars;
  char *pathUsingEnvVarAndSanitizedPath;
  char *relativePathToParent;
  char *resolvedFilePath;
  char *sanitizedFilePath;
  char *stringDuplicate;
  FILE *filePtr;
  resolvedFilePath = NULL;
  fileOpenMode = "rb";
  filePtr = fopen((char *)unresolvedFilePath, (char *)fileOpenMode);
  if (filePtr) {
    size_t filePathLen;
    size_t sizeOfChar;
    filePathLen = strlen((char *)unresolvedFilePath) + 1;
    sizeOfChar = 1;
    stringDuplicate = (char *)calloc(filePathLen, sizeOfChar);
    stringConcat(stringDuplicate, unresolvedFilePath, filePathLen);
    resolvedFilePath = stringDuplicate;
    fclose(filePtr);
  } else {
    computedPathUsingEnvVars =
        computeFilePathUsingEnvVariable(unresolvedFilePath);
    filePtr = fopen(computedPathUsingEnvVars, (char *)fileOpenMode);
    if (filePtr) {
      resolvedFilePath = computedPathUsingEnvVars;
      fclose(filePtr);
    } else {
      free(computedPathUsingEnvVars);
      sanitizedFilePath = sanitizeFilePathForHSP(unresolvedFilePath);
      filePtr = fopen(sanitizedFilePath, (char *)fileOpenMode);
      if (filePtr) {
        resolvedFilePath = sanitizedFilePath;
        fclose(filePtr);
      } else {
        relativePathToParent =
            getRelativePathToParentFolder(unresolvedFilePath);
        filePtr = fopen(relativePathToParent, (char *)fileOpenMode);
        if (filePtr) {
          resolvedFilePath = relativePathToParent;
          fclose(filePtr);
        } else {
          free(relativePathToParent);
          pathUsingEnvVarAndSanitizedPath =
              computeFilePathUsingEnvVariable(sanitizedFilePath);
          filePtr =
              fopen(pathUsingEnvVarAndSanitizedPath, (char *)fileOpenMode);
          if (filePtr) {
            resolvedFilePath = pathUsingEnvVarAndSanitizedPath;
            fclose(filePtr);
          } else {
            free(pathUsingEnvVarAndSanitizedPath);
            exit(EXIT_FAILURE);
          }
        }
      }
    }
  }
  return resolvedFilePath;
}

/*
 * Arguments    : int M
 *                int K
 *                int N
 *                const float *A
 *                int LDA
 *                const float *B
 *                int LDB
 *                float *C
 *                int LDC
 * Return Type  : void
 */
static void macroKernel1(int M, int K, int N, const float *A, int LDA,
                         const float *B, int LDB, float *C, int LDC)
{
  int idxB;
  int j;
  j = 0;
  idxB = 0;
  while (j <= N - 1) {
    int i;
    int idxA;
    int idxC;
    idxC = LDC * j;
    i = 0;
    idxA = 0;
    while (i <= M - 28) {
      microKernel11(K, &A[idxA], LDA, &B[idxB], &C[idxC]);
      idxA += 28;
      idxC += 28;
      i += 28;
    }
    while (i <= M - 4) {
      microKernel12(K, &A[idxA], LDA, &B[idxB], &C[idxC]);
      idxA += 4;
      idxC += 4;
      i += 4;
    }
    while (i <= M - 1) {
      microKernel13(K, &A[idxA], LDA, &B[idxB], &C[idxC]);
      idxA++;
      idxC++;
      i++;
    }
    idxB += LDB;
    j++;
  }
}

/*
 * Arguments    : int M
 *                int K
 *                int N
 *                int blockSizeM
 *                int blockSizeK
 *                int blockSizeN
 *                const float *A
 *                const float *B
 *                float *C
 * Return Type  : void
 */
static void matrixMultiply1(int M, int K, int N, int blockSizeM, int blockSizeK,
                            int blockSizeN, const float *A, const float *B,
                            float *C)
{
  const float *ptrB;
  int b_i;
  int b_j1;
  int i;
  int i0;
  int i0_ub;
  int k0;
  int k0_ub;
  memset(C, 0, (unsigned int)((M * N) << 2));
  if (blockSizeM >= M) {
    blockSizeM = M;
  } else {
    blockSizeM = div_nde_s32_floor(blockSizeM) * 28;
    if (blockSizeM <= 0) {
      blockSizeM = 1;
    }
  }
  if (blockSizeN >= N) {
    blockSizeN = N;
  } else if (blockSizeN <= 0) {
    blockSizeN = 1;
  }
  i0_ub = div_s32_floor(M - 1, blockSizeM) + 1;
  k0_ub = div_s32_floor(K - 1, blockSizeK) + 1;
  for (b_j1 = 0; b_j1 < N; b_j1 += blockSizeN) {
    int N2;
    if (b_j1 > N - blockSizeN) {
      N2 = N - b_j1;
    } else {
      N2 = blockSizeN;
    }
    for (k0 = 1; k0 <= k0_ub; k0++) {
      int K2;
      int k;
      k = (k0 - 1) * blockSizeK;
      if (k > K - blockSizeK) {
        K2 = K - k;
      } else {
        K2 = blockSizeK;
      }
      ptrB = &B[k + K * b_j1];
#pragma omp parallel for num_threads(omp_get_max_threads()) private(i, b_i)

      for (i0 = 1; i0 <= i0_ub; i0++) {
        i = (i0 - 1) * blockSizeM;
        if (i > M - blockSizeM) {
          b_i = M - i;
        } else {
          b_i = blockSizeM;
        }
        macroKernel1(b_i, K2, N2, &A[i + M * k], M, ptrB, K, &C[i + M * b_j1],
                     M);
      }
    }
  }
}

/*
 * Arguments    : int K
 *                const float *A
 *                int LDA
 *                const float *B
 *                float *C
 * Return Type  : void
 */
static void microKernel11(int K, const float *A, int LDA, const float *B,
                          float *C)
{
  __m128 b_c;
  __m128 c;
  __m128 c_c;
  __m128 d_c;
  __m128 e_c;
  __m128 f_c;
  __m128 g_c;
  int idxA;
  int idxB;
  int k;
  idxA = 0;
  idxB = 0;
  c = _mm_loadu_ps(&C[0]);
  b_c = _mm_loadu_ps(&C[4]);
  c_c = _mm_loadu_ps(&C[8]);
  d_c = _mm_loadu_ps(&C[12]);
  e_c = _mm_loadu_ps(&C[16]);
  f_c = _mm_loadu_ps(&C[20]);
  g_c = _mm_loadu_ps(&C[24]);
  for (k = 0; k < K; k++) {
    __m128 aFloat;
    __m128 b;
    __m128 b_aFloat;
    __m128 c_aFloat;
    __m128 d_aFloat;
    __m128 e_aFloat;
    __m128 f_aFloat;
    __m128 g_aFloat;
    aFloat = _mm_loadu_ps(&A[idxA]);
    b_aFloat = _mm_loadu_ps(&A[idxA + 4]);
    c_aFloat = _mm_loadu_ps(&A[idxA + 8]);
    d_aFloat = _mm_loadu_ps(&A[idxA + 12]);
    e_aFloat = _mm_loadu_ps(&A[idxA + 16]);
    f_aFloat = _mm_loadu_ps(&A[idxA + 20]);
    g_aFloat = _mm_loadu_ps(&A[idxA + 24]);
    b = _mm_set1_ps(B[idxB]);
    c = _mm_add_ps(c, _mm_mul_ps(aFloat, b));
    b_c = _mm_add_ps(b_c, _mm_mul_ps(b_aFloat, b));
    c_c = _mm_add_ps(c_c, _mm_mul_ps(c_aFloat, b));
    d_c = _mm_add_ps(d_c, _mm_mul_ps(d_aFloat, b));
    e_c = _mm_add_ps(e_c, _mm_mul_ps(e_aFloat, b));
    f_c = _mm_add_ps(f_c, _mm_mul_ps(f_aFloat, b));
    g_c = _mm_add_ps(g_c, _mm_mul_ps(g_aFloat, b));
    idxA += LDA;
    idxB++;
  }
  _mm_storeu_ps(&C[0], c);
  _mm_storeu_ps(&C[4], b_c);
  _mm_storeu_ps(&C[8], c_c);
  _mm_storeu_ps(&C[12], d_c);
  _mm_storeu_ps(&C[16], e_c);
  _mm_storeu_ps(&C[20], f_c);
  _mm_storeu_ps(&C[24], g_c);
}

/*
 * Arguments    : int K
 *                const float *A
 *                int LDA
 *                const float *B
 *                float *C
 * Return Type  : void
 */
static void microKernel12(int K, const float *A, int LDA, const float *B,
                          float *C)
{
  __m128 c;
  int idxA;
  int idxB;
  int k;
  idxA = 0;
  idxB = 0;
  c = _mm_loadu_ps(&C[0]);
  for (k = 0; k < K; k++) {
    __m128 aFloat;
    aFloat = _mm_loadu_ps(&A[idxA]);
    c = _mm_add_ps(c, _mm_mul_ps(aFloat, _mm_set1_ps(B[idxB])));
    idxA += LDA;
    idxB++;
  }
  _mm_storeu_ps(&C[0], c);
}

/*
 * Arguments    : int K
 *                const float *A
 *                int LDA
 *                const float *B
 *                float *C
 * Return Type  : void
 */
static void microKernel13(int K, const float *A, int LDA, const float *B,
                          float *C)
{
  float c;
  int idxA;
  int idxB;
  int k;
  idxA = 0;
  idxB = 0;
  c = C[0];
  for (k = 0; k < K; k++) {
    c += A[idxA] * B[idxB];
    idxA += LDA;
    idxB++;
  }
  C[0] = c;
}

/*
 * Arguments    : float *inputBufferPtr
 *                const char *unresolvedFilePath
 *                int numElementsToRead
 * Return Type  : void
 */
static void readDnnConstants(float *inputBufferPtr,
                             const char *unresolvedFilePath,
                             int numElementsToRead)
{
  int elementSizeInBytes;
  const char *fileOpenMode;
  char *resolvedFilePath;
  FILE *filePtr;
  void *dataBufferPtr;
  resolvedFilePath = getResolvedFilePath(unresolvedFilePath);
  fileOpenMode = "rb";
  filePtr = fopen(resolvedFilePath, (char *)fileOpenMode);
  dataBufferPtr = &inputBufferPtr[0];
  elementSizeInBytes = 4;
  fread(dataBufferPtr, elementSizeInBytes, numElementsToRead, filePtr);
  fclose(filePtr);
  free(resolvedFilePath);
}

/*
 * Arguments    : const char *unresolvedFilePath
 * Return Type  : char *
 */
static char *resolveBinaryFilePath(const char *unresolvedFilePath)
{
  const char *c_filePathAfterSlicingRelativeP;
  const char *c_leadingPathSeparatorUnixAndWi;
  const char *codegenDirStrInMWDLDataPath;
  const char *d_filePathAfterSlicingRelativeP;
  const char *mwDLDataPath;
  char *codegenDir;
  char *coderDataPath;
  char *resolvedFilePath;
  char *updatedStartDir;
  size_t sizeOfChar;
#define XSTR(x) #x
#define STR(x) XSTR(x)
  coderDataPath = getenv("CODER_DATA_PATH");
  sizeOfChar = 1;
  if (coderDataPath != NULL) {
    resolvedFilePath = getCustomUserDataPathEnvVar(unresolvedFilePath);
  } else {
    size_t filePathLen;
    size_t posOfCodegenDir;
    size_t posOfLeadingPathSeparator;
    mwDLDataPath = STR(MW_DL_DATA_PATH);
    c_filePathAfterSlicingRelativeP = &unresolvedFilePath[2];
    c_leadingPathSeparatorUnixAndWi = "/\\";
    posOfLeadingPathSeparator =
        strcspn((char *)c_filePathAfterSlicingRelativeP,
                (char *)c_leadingPathSeparatorUnixAndWi);
    filePathLen = posOfLeadingPathSeparator + 1;
    codegenDir = (char *)calloc(filePathLen, sizeOfChar);
    strncpy(codegenDir, (char *)c_filePathAfterSlicingRelativeP,
            posOfLeadingPathSeparator);
    codegenDirStrInMWDLDataPath = strstr((char *)mwDLDataPath, codegenDir);
    if (codegenDirStrInMWDLDataPath == NULL) {
      posOfCodegenDir = strlen((char *)mwDLDataPath);
    } else {
      posOfCodegenDir = codegenDirStrInMWDLDataPath - mwDLDataPath;
    }
    if (posOfCodegenDir == strlen((char *)mwDLDataPath)) {
      size_t b_filePathLen;
      d_filePathAfterSlicingRelativeP = &unresolvedFilePath[1];
      b_filePathLen = (strlen((char *)mwDLDataPath) +
                       strlen((char *)d_filePathAfterSlicingRelativeP)) +
                      1;
      resolvedFilePath = (char *)calloc(b_filePathLen, sizeOfChar);
      stringConcat(resolvedFilePath, mwDLDataPath, b_filePathLen);
      stringConcat(resolvedFilePath, d_filePathAfterSlicingRelativeP,
                   b_filePathLen);
    } else {
      size_t c_filePathLen;
      c_filePathLen = posOfCodegenDir + 1;
      updatedStartDir = (char *)calloc(c_filePathLen, sizeOfChar);
      strncpy(updatedStartDir, (char *)mwDLDataPath, posOfCodegenDir);
      c_filePathLen = (strlen(updatedStartDir) +
                       strlen((char *)c_filePathAfterSlicingRelativeP)) +
                      1;
      resolvedFilePath = (char *)calloc(c_filePathLen, sizeOfChar);
      stringConcat(resolvedFilePath, updatedStartDir, c_filePathLen);
      stringConcat(resolvedFilePath, c_filePathAfterSlicingRelativeP,
                   c_filePathLen);
      free(updatedStartDir);
    }
    free(codegenDir);
  }
#undef XSTR
#undef STR
  return resolvedFilePath;
}

/*
 * Arguments    : const char *unSanitizedFilePath
 * Return Type  : char *
 */
static char *sanitizeFilePathForHSP(const char *unSanitizedFilePath)
{
  char *sanitizedFilePath;
  char *stringDuplicate;
  size_t charIdx;
  size_t filePathLen;
  size_t sizeOfChar;
  filePathLen = strlen((char *)unSanitizedFilePath) + 1;
  sizeOfChar = 1;
  stringDuplicate = (char *)calloc(filePathLen, sizeOfChar);
  stringConcat(stringDuplicate, unSanitizedFilePath, filePathLen);
  sanitizedFilePath = stringDuplicate;
  for (charIdx = 0; charIdx < strlen((char *)unSanitizedFilePath); charIdx++) {
    char charToCheckFor;
    charToCheckFor = unSanitizedFilePath[charIdx];
    if (isspace(charToCheckFor)) {
      sanitizedFilePath[charIdx] = '_';
    }
  }
  return sanitizedFilePath;
}

/*
 * Arguments    : char *destinationString
 *                const char *sourceString
 *                size_t destBufferSize
 * Return Type  : void
 */
static void stringConcat(char *destinationString, const char *sourceString,
                         size_t destBufferSize)
{
  size_t dstStringLen;
  size_t srcBuffIdx;
  dstStringLen = strlen(destinationString);
  srcBuffIdx = 0;
  while ((sourceString[srcBuffIdx] != '\x00') &&
         (dstStringLen < destBufferSize - 1)) {
    destinationString[dstStringLen] = sourceString[srcBuffIdx];
    dstStringLen++;
    srcBuffIdx++;
  }
  destinationString[dstStringLen] = '\x00';
}

/*
 * Arguments    : const float inputsT_0_f1[4]
 * Return Type  : float
 */
float predict(const float inputsT_0_f1[4])
{
  static const float t0_Weights[800] = {
      0.089151293F,     0.00114516832F,   0.151775196F,     0.452775627F,
      0.925112367F,     -1.90406907F,     -4.21941513E-5F,  -0.00469146809F,
      -0.168168023F,    -0.582775533F,    0.219256F,        -1.03599778E-12F,
      0.491821647F,     1.39635875E-13F,  -3.49196744F,     -0.399001122F,
      0.0416740291F,    1.51953259E-6F,   -0.387699783F,    -0.376130044F,
      0.0393156894F,    0.00764679257F,   0.277307928F,     0.0284304861F,
      -3.87466E-24F,    0.67986238F,      0.193956509F,     -0.735192657F,
      -2.15216708F,     -0.0323138684F,   4.22750915E-16F,  0.0179806408F,
      0.231007069F,     -0.0141680567F,   1.98310316F,      0.244501725F,
      0.0210407432F,    0.00321043748F,   -3.19939477E-6F,  -0.0720567107F,
      0.222512931F,     -0.0855545923F,   4.65132963E-8F,   7.39898751E-5F,
      -0.173443735F,    -0.175701186F,    0.0172437094F,    -0.0114034526F,
      0.131756306F,     -0.000371189934F, 0.000209550315F,  6.73752447E-6F,
      -0.00030758F,     0.319612056F,     0.000168178463F,  1.06766665F,
      -0.176595315F,    3.62639236F,      -0.203402832F,    0.47561869F,
      0.0666381493F,    0.428792149F,     0.0029493731F,    -0.0792298242F,
      0.305103362F,     -0.00940201432F,  -0.307089657F,    -0.47692275F,
      7.33376E-9F,      7.2241E-7F,       -0.0119518498F,   0.0295479037F,
      -2.29882462E-5F,  -0.00861125533F,  0.578844965F,     0.437108159F,
      0.0247356202F,    0.00589117175F,   0.000239292116F,  2.37199549E-15F,
      -0.0207888912F,   -0.745522738F,    -2.85375393E-7F,  -0.0545344763F,
      0.178876907F,     -0.803486168F,    2.58261625E-5F,   0.0277809147F,
      0.279053926F,     -0.11015705F,     -0.0792157799F,   0.0575589091F,
      1.49734731E-7F,   -0.000145693673F, 0.00588698825F,   2.18243076E-6F,
      0.532269776F,     -0.0045981193F,   -0.0807408F,      0.515731573F,
      -0.0110029569F,   -8.32761216E-5F,  -0.0407451279F,   0.154378831F,
      4.90861E-41F,     3.18574309E-14F,  0.225054F,        1.7325716F,
      1.34821904F,      -0.377750307F,    -5.66728559E-5F,  -3.41840649F,
      0.0933577418F,    0.00463768933F,   0.0184173025F,    -0.349803478F,
      0.289228261F,     -0.77605027F,     -0.731430829F,    -0.500380039F,
      0.402531296F,     5.30564463E-8F,   6.31669172E-6F,   0.298130751F,
      -3.43045594E-26F, -1.73038709F,     -2.47488332F,     -2.55453906E-5F,
      -1.9020732E-5F,   1.78908649E-20F,  -0.0655341223F,   -0.0359933302F,
      -0.360243499F,    0.00315245707F,   1.72987E-39F,     0.00447144127F,
      0.116737522F,     -9.14128293E-8F,  3.30952133E-7F,   1.74195135F,
      -0.130417377F,    0.000433392823F,  -0.00144823536F,  -0.0643307194F,
      0.00692583527F,   0.44389683F,      0.0681182221F,    1.2843796F,
      0.330066204F,     8.35473202E-7F,   1.71050506E-5F,   6.19218772E-5F,
      -2.23321567E-5F,  0.051589109F,     0.141257063F,     9.71339453E-9F,
      -2.8521887E-13F,  0.00140251673F,   0.425076544F,     0.080078952F,
      -0.527145267F,    -0.0242959745F,   2.57533574F,      -0.206862941F,
      0.0187854432F,    6.96698343E-9F,   0.0782153F,       -0.147246823F,
      0.444251567F,     -0.00415146723F,  -3.54417181F,     0.539194643F,
      0.574462414F,     0.145499513F,     0.179603577F,     0.014128F,
      3.83476761E-9F,   -0.61612767F,     -5.07152663E-7F,  -1.8668741F,
      0.516989231F,     8.90554617E-8F,   1.11810386F,      0.361523211F,
      5.84687576E-10F,  1.09707216E-7F,   -0.000109667046F, -0.192757517F,
      2.17653823F,      0.0800491422F,    2.15027593E-15F,  0.375003546F,
      1.4064151F,       -1.22145367F,     0.00514876284F,   0.322012872F,
      -0.0167857539F,   -1.04696486E-11F, -0.296199262F,    -0.000502972864F,
      0.350473285F,     0.0229423475F,    -0.126388282F,    -0.00643065711F,
      0.466880709F,     -1.61692822F,     -0.00181754038F,  0.0113526601F,
      -0.08861541F,     -0.189206049F,    0.217514113F,     0.000184825389F,
      -0.027488485F,    4.81235628E-15F,  -2.24435616F,     0.0833438113F,
      0.117628038F,     0.000384371291F,  0.177969247F,     -0.127912387F,
      0.0868926346F,    0.0391450077F,    0.162877157F,     0.0583307035F,
      -8.39198378E-7F,  1.14550161F,      -0.184341103F,    0.56611824F,
      -1.38642955F,     0.230852932F,     -2.46551585E-10F, -0.0128116794F,
      -0.164594069F,    -0.0246273261F,   2.46246362F,      0.168462753F,
      -0.0436558202F,   0.00465153717F,   0.00243698037F,   0.0918448567F,
      0.124658406F,     1.37814939F,      8.38735359E-5F,   0.00657313969F,
      -0.0515937F,      -0.0347274467F,   0.0144151011F,    0.18330875F,
      -0.158038333F,    0.00936388131F,   0.00380410696F,   -0.00320287282F,
      0.000489966536F,  -0.0987867862F,   0.00263037509F,   1.52964199F,
      -0.343403727F,    0.963036895F,     -0.509997129F,    -0.112279356F,
      -0.196214333F,    0.457013279F,     -0.0122882323F,   0.198403791F,
      1.2949692F,       0.00830795616F,   -0.139439046F,    -0.804422379F,
      0.00053636F,      -0.00103696785F,  0.0438863151F,    -0.0375282317F,
      -0.0110285664F,   0.0334198847F,    0.0864861906F,    -0.67895478F,
      -0.073200196F,    -0.00335100829F,  0.00250723958F,   -9.72410703E-7F,
      -0.121523097F,    0.672391534F,     -0.000164814512F, 0.0913918689F,
      0.650018752F,     0.208443552F,     0.000878145627F,  0.0744352F,
      -0.044152189F,    0.0898506418F,    0.773375273F,     0.043546591F,
      -1.49949506E-6F,  0.00731420564F,   0.00939238816F,   -0.00029365826F,
      0.781799674F,     -0.00878775213F,  0.0107931411F,    -0.530231953F,
      -0.0137553904F,   -0.00576628931F,  0.170135483F,     -0.295313686F,
      -7.02960693E-22F, 3.05188314E-6F,   -0.130475402F,    1.45730674F,
      0.388621271F,     0.303239405F,     0.00347766816F,   -1.48769128F,
      -0.0243606269F,   0.113581479F,     0.241772681F,     0.0966010615F,
      -0.0492674783F,   -0.0448033102F,   0.179698378F,     -0.906726301F,
      -0.212983504F,    7.03802925E-7F,   0.00530680781F,   -0.100744277F,
      -2.91303934E-7F,  -1.73301911F,     -0.837954402F,    -0.00177069171F,
      -0.00279013254F,  4.78195883E-9F,   -0.044451721F,    0.572119355F,
      0.457841158F,     0.00353023224F,   2.05026152E-11F,  0.167790234F,
      0.0864995345F,    -0.0022855245F,   -0.000190075065F, 0.489259571F,
      -0.236763194F,    0.00775519433F,   -0.0101437513F,   0.179057568F,
      -0.227230325F,    0.342359215F,     0.00336878F,      0.297263563F,
      0.217802823F,     -0.0262117423F,   0.004440038F,     0.000352166826F,
      0.128336191F,     -0.113149203F,    -0.15911144F,     0.000454934954F,
      2.14377656E-6F,   0.000483838114F,  0.369717062F,     -0.0316000283F,
      -0.940799117F,    0.159081832F,     0.348917156F,     -0.23315835F,
      0.135916516F,     0.00546663674F,   0.600517452F,     0.171705768F,
      -0.6546579F,      0.0970493332F,    -0.983448684F,    0.491277933F,
      0.810193F,        0.027206663F,     0.297089517F,     -0.723080575F,
      0.000226475837F,  -1.14865828F,     3.9887731E-5F,    -0.972431779F,
      0.749961317F,     0.00254387641F,   1.2911042F,       0.46683529F,
      0.000246293173F,  9.01639723E-5F,   0.00347662228F,   0.223824665F,
      0.305336803F,     0.576538265F,     9.903506E-6F,     -0.210333675F,
      0.475022614F,     -0.280614465F,    -0.0720274597F,   0.649895F,
      0.0641602203F,    0.00173071818F,   0.58483988F,      0.0304194894F,
      0.00768444035F,   0.00302736438F,   0.0311459638F,    0.8529585F,
      0.136071727F,     -1.15921223F,     -0.00348353176F,  -0.0352110453F,
      -0.0402848162F,   -0.0777784064F,   -0.273944587F,    0.00299806381F,
      -0.101089187F,    3.32416203E-19F,  -1.71544588F,     -0.242077053F,
      -0.0497784242F,   3.42515632E-5F,   0.00496263336F,   -0.134400263F,
      0.0395718589F,    0.00428949809F,   -0.387465388F,    0.0354439355F,
      0.000223002149F,  0.342777848F,     -0.397774458F,    0.154404953F,
      -1.13443565F,     0.247520387F,     2.1886224E-7F,    -0.307791859F,
      -0.39050293F,     0.0261481013F,    0.674111784F,     0.154152334F,
      0.0373460427F,    -0.00828688685F,  -0.0332215428F,   -0.16084139F,
      -0.166038111F,    -0.142222747F,    -0.00325671653F,  -0.0153378714F,
      -0.00400478812F,  -0.17128104F,     -0.00517186103F,  -0.0155478735F,
      -0.260141402F,    -0.0527349599F,   -0.0158468876F,   0.00126629882F,
      0.0407571904F,    -0.0363177F,      -0.0272047818F,   0.421665072F,
      -0.0176576972F,   -0.64802587F,     -0.938363194F,    -0.273736894F,
      -0.177222669F,    -0.379735678F,    -0.014935202F,    0.337099314F,
      0.54007715F,      0.0290724598F,    -0.073262684F,    -0.835572124F,
      -0.0140367616F,   -0.00306101353F,  0.00731346849F,   0.00686467718F,
      0.0016013952F,    -0.00294749695F,  -0.0170217808F,   -0.0630171522F,
      0.194699332F,     -0.0174788143F,   0.00806221832F,   7.36942596E-9F,
      -0.113647312F,    -0.0530084297F,   0.00124815374F,   0.216538399F,
      0.643531561F,     -0.361629426F,    0.00617138157F,   0.00793255586F,
      -0.314656943F,    -0.0495362543F,   0.139202967F,     0.00721137365F,
      2.51359938E-6F,   -0.000165622288F, 0.0212484468F,    0.0086660441F,
      -1.30318451F,     -0.0714731961F,   0.1078289F,       0.0165256355F,
      0.00343133882F,   -0.0857425779F,   -0.0612788759F,   -0.450177848F,
      5.02884E-41F,     3.57027238E-5F,   -0.249080196F,    -1.33499658F,
      0.575101F,        0.152311429F,     7.68993268E-5F,   -0.632087827F,
      -0.0340282917F,   -0.0600163266F,   0.0498926267F,    -0.264625788F,
      -0.680087149F,    -0.0129202073F,   -0.037909694F,    -1.51944637F,
      0.169940859F,     1.28724205E-5F,   -0.0253180955F,   0.189135179F,
      -0.000499375456F, -2.00736785F,     1.10148013F,      -0.031914331F,
      -0.00790651608F,  -4.87432123E-14F, 0.00847846F,      -0.879351F,
      0.898020804F,     -0.000103169048F, 7.25346922E-7F,   0.221255764F,
      -0.232165292F,    -0.00297369878F,  -0.000158049617F, -0.952387631F,
      0.026164731F,     0.00225766702F,   -0.0494345874F,   0.0234300308F,
      -0.267357618F,    -0.327600896F,    -0.0407073312F,   0.736769795F,
      0.237986714F,     -0.0188055672F,   0.0157199F,       -0.0180997066F,
      -0.0196267609F,   -0.0733651221F,   0.177561596F,     -0.00111049961F,
      -0.00168294949F,  -0.0549841337F,   0.250434548F,     -0.32309562F,
      -1.51244283F,     -0.0695723146F,   0.218465373F,     0.0751727149F,
      0.0290858243F,    -0.000303704641F, 0.281148821F,     -0.304429114F,
      -0.598518372F,    0.0333554149F,    1.7417928F,       -0.382119119F,
      0.0259253103F,    0.0477293655F,    0.119130708F,     -0.0960642323F,
      0.00276888814F,   -0.720855713F,    0.00328041427F,   -4.39101458F,
      -0.213713229F,    0.0010350435F,    -0.329791665F,    -0.0467153713F,
      0.00455686217F,   -1.24410153E-5F,  -8.07478791E-5F,  -0.154657528F,
      0.0803281292F,    1.32665396F,      0.00394086819F,   0.296941638F,
      0.937670052F,     0.253659099F,     -0.10149347F,     -0.248768285F,
      -0.108483732F,    -0.00590331107F,  -1.98232102F,     -0.00499549182F,
      0.0271727145F,    0.00201573642F,   0.0556674413F,    0.381123662F,
      0.062272545F,     -0.612592459F,    0.00178972015F,   0.0056424858F,
      0.0116987433F,    0.00298404018F,   0.282070279F,     -0.00270365388F,
      0.0185471885F,    1.47778371E-6F,   -0.721346438F,    -0.12229047F,
      -0.000868025876F, -0.000507887278F, 0.00062013237F,   -0.0267694127F,
      0.00490224874F,   0.00508514745F,   -0.0147606079F,   0.0020219523F,
      -0.000346337794F, 0.210129037F,     -0.0283812918F,   -0.0940392464F,
      -0.235198F,       0.021011034F,     1.64572214E-6F,   0.0962877721F,
      0.176303744F,     0.00846526F,      0.432215929F,     0.0153659796F,
      0.00112121273F,   0.000666180393F,  0.0013188771F,    -0.0816940069F,
      -0.0641436502F,   -0.09334483F,     -0.000528904842F, -0.00275352597F,
      0.00200318801F,   0.112865686F,     -0.00222687516F,  0.0160517283F,
      0.0507584773F,    -0.00118177966F,  -0.00312178815F,  -0.000544490293F,
      0.00198827591F,   0.013235176F,     0.0053110132F,    0.24870871F,
      0.0104368683F,    -0.0441649593F,   0.0939843282F,    0.275884777F,
      -0.183747679F,    0.100882769F,     -0.00204836437F,  0.0054638125F,
      0.329687417F,     -0.00261374936F,  0.205538705F,     0.055314593F,
      -0.00100491871F,  -7.19135E-5F,     0.0103202527F,    0.0166537091F,
      -0.00171165064F,  0.00385618769F,   -0.139054686F,    0.0239644479F,
      -0.00401241193F,  -0.00717916247F,  0.00588839734F,   -1.54588724E-5F,
      -0.0260468125F,   0.0558217205F,    0.000289746531F,  0.00175736973F,
      0.0734182894F,    -0.0704235211F,   -0.000191482308F, 0.0198643133F,
      0.11817202F,      -0.00881650485F,  0.131460309F,     0.00150959392F,
      -3.44469481E-5F,  -0.000105210849F, -0.00994095579F,  0.00144228619F,
      -0.845687687F,    0.000319286861F,  0.0140156709F,    0.128154606F,
      0.00202162913F,   0.00369005231F,   0.0146498783F,    -0.115798064F,
      1.49604534E-16F,  -0.000394114963F, -0.0122478101F,   -0.611058056F,
      0.0586126372F,    0.119768493F,     0.00126456318F,   -0.143582493F,
      0.00463305553F,   0.00245371973F,   0.00661799684F,   0.300526F,
      0.271141142F,     0.0433365144F,    0.476641744F,     -0.312733382F,
      0.186529875F,     -0.000166935468F, 0.00011383128F,   0.591217339F,
      -7.97601897E-5F,  -0.481298089F,    0.126243636F,     0.00347752287F,
      4.40084259E-5F,   -1.78605546E-7F,  -0.00768905785F,  0.035679F,
      0.40501678F,      -0.000137715047F, 2.86076079E-6F,   0.0141550545F,
      -0.0453032739F,   -0.000496303954F, -7.89350306E-5F,  -0.0109280702F,
      0.00600806298F,   0.000183623473F,  0.00458192546F,   -0.00108204677F,
      -0.00500186812F,  0.0152565986F,    0.00303234486F,   0.0544974171F,
      0.0326216631F,    -0.00137274736F,  -0.000798306777F, -0.00258456101F,
      0.00595924072F,   0.105767384F,     0.0373830684F,    0.000304588233F,
      -0.000416572817F, -0.000954314193F, 0.0255687535F,    0.449010342F,
      0.47148326F,      0.0025363022F,    -0.348132968F,    0.000261520559F,
      0.00672268029F,   -0.000829740311F, 0.0207086038F,    -0.174469918F,
      0.368592709F,     0.00847722217F,   0.388735563F,     -0.158814833F,
      -0.0238964353F,   0.00160679629F,   0.068966493F,     0.0703688413F,
      -0.000171724212F, 0.0594325028F,    -0.000184328776F, -0.700810373F,
      0.0212059915F,    -0.000141690849F, -0.275596946F,    0.0498405546F,
      0.000607087044F,  0.000419941673F,  0.000269427546F,  -0.0674619749F,
      0.302411526F,     0.195752874F,     0.000252575759F,  0.241061345F,
      0.17574966F,      -0.150117442F,    0.0255013872F,    0.2886886F,
      -0.0415802076F,   -0.00223994302F,  -1.10596633F,     -0.000704027188F};
  static const float a[200] = {
      0.0375561267F,    -0.148785815F,    -0.195302576F,   -0.0144614978F,
      -0.0046402826F,   -0.0294294376F,   0.00214224728F,  -0.0940716714F,
      0.0146593843F,    0.479810178F,     -0.00539085316F, 0.00391300535F,
      0.140676722F,     -0.067862317F,    -0.0204543844F,  -0.0200436749F,
      0.0726363733F,    -0.000785290089F, 0.0486803316F,   -0.00114409544F,
      0.0416763276F,    -0.000155539819F, 6.23725064E-5F,  -0.0140961409F,
      -0.191978619F,    0.0243562255F,    0.0240652822F,   -0.219197094F,
      0.0051933662F,    0.0319839157F,    -8.38957112E-6F, 0.0619405732F,
      -0.0305798128F,   0.0131908022F,    -0.00896211248F, -0.0047225547F,
      0.0233878791F,    -0.14793472F,     -0.00027641037F, 0.174752116F,
      -0.0517853536F,   -0.124818452F,    0.0728400126F,   1.57302487F,
      0.000901919848F,  -0.00476597669F,  -0.0429713242F,  -0.00509581435F,
      0.0115713049F,    0.155370057F,     0.0658541471F,   0.0509830043F,
      0.0659473464F,    0.00847261213F,   -0.00377949164F, 2.60916886E-6F,
      0.0818141699F,    -1.13120925F,     0.212154046F,    0.0273775607F,
      -0.00308850803F,  0.00433653919F,   -0.0259029F,     -0.0233079586F,
      -0.0424025767F,   -0.060466975F,    0.026084112F,    -0.00287985383F,
      1.25198019F,      -0.0228627175F,   -0.0751436874F,  0.0783679187F,
      0.00659340154F,   -0.047056146F,    -0.00888446812F, -0.0284419898F,
      -0.0681350455F,   -0.00523087103F,  -0.0104085514F,  0.421279609F,
      -0.0159433912F,   -0.436566502F,    -0.00863160752F, 0.005531542F,
      0.0108800409F,    0.0151131954F,    -0.00458284F,    -0.00211092527F,
      -0.00291310716F,  0.0110601019F,    0.00514521776F,  -0.00664646F,
      -0.0470132865F,   -0.00277641811F,  0.0672349781F,   -0.0801904649F,
      -0.0755023509F,   -0.0191639643F,   -0.00058025145F, -0.114733621F,
      0.11609453F,      -0.0804675817F,   -0.0423276685F,  -0.00081437506F,
      0.050853394F,     0.129527181F,     0.110169977F,    0.00692649418F,
      -0.905349374F,    0.00495800795F,   0.0758529752F,   -0.0122644724F,
      0.0277993362F,    -1.40972F,        -0.0045433091F,  -0.0923639461F,
      0.00181292766F,   -0.0561612323F,   0.0199518353F,   -0.588749886F,
      0.00846325327F,   -0.0350296125F,   -0.00809815F,    -0.0164175276F,
      0.00153089897F,   -0.00677462388F,  -0.0897598639F,  -0.274414629F,
      0.00230499869F,   0.00561509142F,   -0.149606168F,   0.0818782076F,
      0.0518548F,       0.0114084641F,    0.636444211F,    -0.0650078505F,
      -3.03293928E-6F,  -0.0389945507F,   0.0415237583F,   0.000435233262F,
      -0.075320892F,    6.39583886E-5F,   -0.0293052737F,  0.0526117571F,
      0.0754879117F,    0.124528348F,     -0.00768247247F, -0.0928816721F,
      -0.0659412742F,   -0.00260953279F,  0.0106138149F,   -0.129007816F,
      -0.0721005127F,   -0.0324820913F,   -0.0297528356F,  -0.166512445F,
      0.0123811606F,    -0.000893058546F, 0.0191512145F,   0.0412786976F,
      -0.30307889F,     0.00446567452F,   -0.0979335234F,  0.00265503861F,
      -0.227982938F,    0.0141398907F,    -0.00142640679F, 0.108329684F,
      -0.00933077466F,  0.00738327717F,   0.00018463521F,  -0.0074756816F,
      -0.000187923986F, -0.132035181F,    0.0125608575F,   0.221871063F,
      0.00157997455F,   -0.00523251574F,  0.0315103568F,   0.000621200888F,
      0.11380671F,      -0.0241386704F,   0.153309584F,    -1.81176269F,
      1.66558969F,      0.116372511F,     0.00206156541F,  0.0285078473F,
      3.22394705F,      -0.0119106648F,   0.0809337199F,   0.0172532499F,
      0.158218116F,     0.152342558F,     0.0019416702F,   -1.38293854E-5F,
      0.00354064442F,   0.0117848627F,    0.0255630724F,   0.0882234797F};
  static const float fv[200] = {
      -0.532906115F,    -0.14088209F,    -0.567586601F,    -0.858710289F,
      -0.613686144F,    -1.09426606F,    -0.150015265F,    -0.288684696F,
      -0.236410528F,    -0.27687794F,    -0.281756461F,    -0.107885197F,
      -0.297576666F,    -4.3830456E-5F,  -3.25598526F,     -0.492068082F,
      -0.444473743F,    -0.0185873825F,  -0.232103422F,    -0.53138876F,
      -0.543151617F,    -0.218405083F,   -0.641667902F,    -0.230314091F,
      -0.014905706F,    -1.16002142F,    -0.264034212F,    -0.367104948F,
      -0.626313925F,    -0.902791321F,   -0.000286932103F, -0.598821044F,
      -0.601555467F,    -0.379270226F,   -1.98969889F,     -0.326949179F,
      -0.302933514F,    -0.144404992F,   -0.138789281F,    -0.556861341F,
      -0.36251846F,     -0.231113151F,   -0.0261367615F,   -0.14748089F,
      -0.233393312F,    -0.276593745F,   -0.127027631F,    -0.658506095F,
      -0.58266896F,     -0.552414417F,   -0.216344804F,    -0.0458715856F,
      -0.217554152F,    -0.421032608F,   -0.497192204F,    -1.19010234F,
      -0.510925353F,    -1.12659872F,    -0.922306776F,    0.101381123F,
      -0.649404466F,    0.0539650731F,   -0.185536519F,    -0.908300102F,
      -1.15409839F,     -0.473555F,      -0.318269342F,    -0.989883125F,
      -0.0921942145F,   -0.0379186608F,  -0.213695973F,    -0.237303361F,
      -0.132365659F,    -0.252690613F,   -0.547332942F,    -0.802189291F,
      -0.755251348F,    -0.673022866F,   -0.103343084F,    -0.00132554967F,
      -0.597255766F,    -0.199428156F,   -0.0179344509F,   -0.731396794F,
      -0.753007174F,    -0.123443477F,   -0.20855929F,     -0.288362F,
      -0.678676F,       -0.29938063F,    -1.52588308F,     -0.120546885F,
      -0.0104645602F,   -0.0927787423F,  -0.424596816F,    -0.0847779065F,
      -3.0839541F,      -0.242414057F,   -0.0972357616F,   -0.300907463F,
      -0.158004522F,    -0.365215F,      -0.465972692F,    -0.257812709F,
      -3.28136295E-14F, -0.0283480398F,  -0.481880873F,    -2.65145612F,
      -0.635724604F,    -0.68599081F,    -0.0524979234F,   -0.0594103485F,
      -0.376166224F,    -0.318335831F,   -0.405701071F,    -0.0158079285F,
      -0.412598F,       -0.356705487F,   -0.250412494F,    -1.29548252F,
      -0.338685751F,    -0.00597105268F, -0.153176218F,    -0.224035636F,
      -0.00775444601F,  -1.80927289F,    -1.13199961F,     -0.209021732F,
      -0.0707034469F,   -3.92968068E-5F, -0.304221421F,    -1.47683752F,
      -0.989106476F,    -0.0313846171F,  -0.000348997186F, -1.00512254F,
      -0.451385915F,    -0.148757458F,   -0.00489187334F,  -0.831216037F,
      -0.367371619F,    -0.150005F,      -0.401199281F,    -0.302441835F,
      -0.536245167F,    -0.026636593F,   -0.291892052F,    -0.313501239F,
      -0.343434542F,    -0.113523848F,   -0.110876314F,    -0.185968474F,
      -0.444753706F,    -0.127316117F,   -0.355631769F,    -0.0614573099F,
      -0.0545183271F,   -0.287263036F,   -0.292338938F,    -0.488930255F,
      -2.22089863F,     -0.438525051F,   0.533436179F,     -0.558682323F,
      -0.309097201F,    -0.102429405F,   -1.6207608F,      -1.09018421F,
      -0.579880476F,    -0.413097918F,   -1.01393402F,     -0.921270609F,
      -0.534283698F,    -0.554073095F,   -0.508332F,       -0.707114041F,
      -0.0152633619F,   -1.46768415F,    -0.0253814477F,   0.619437754F,
      -0.0283257123F,   -0.0569970272F,  -1.06094193F,     -0.702004492F,
      -0.121290781F,    -0.0194357466F,  -0.0263568815F,   -0.23988685F,
      -0.48429358F,     0.870520949F,    -0.0472333245F,   -0.261326373F,
      -0.616049826F,    -0.223439634F,   -0.535893F,       -0.195990935F,
      -0.668719471F,    -0.131939F,      -2.4063971F,      -0.140102655F};
  static const float fv1[200] = {
      -0.172282219F,    -0.26799953F,     -0.158999205F,    -5.47255786E-6F,
      -0.0583840683F,   -0.00405409886F,  -0.0321087465F,   -0.0969312936F,
      -0.0831676275F,   1.2157284F,       -0.0481682308F,   -0.0275939517F,
      -0.113491841F,    -0.134854302F,    -0.00222789752F,  -0.0812658146F,
      -0.0303328317F,   -0.0753370076F,   -0.199331969F,    -0.0473528281F,
      -0.173400685F,    -0.0409955457F,   -1.69237166E-14F, 0.00211086404F,
      -0.0956312492F,   -0.0163987502F,   -0.141952708F,    -1.41375244F,
      -0.0480427742F,   0.0165635496F,    -2.20506711E-15F, -0.0147704873F,
      -0.0681080893F,   -0.0113353916F,   -0.0130133955F,   -0.163053527F,
      -0.0199347418F,   -0.0515078194F,   -0.00789236743F,  0.235497087F,
      -0.000474782952F, 0.0853533074F,    -0.0371594764F,   -1.14661944F,
      -0.101427339F,    -0.000106738065F, -0.2258389F,      -0.0222710874F,
      0.0239512473F,    -0.138315305F,    -0.0105161788F,   -0.00319289742F,
      -0.0572736748F,   -0.0127004385F,   -0.0461102761F,   -2.45858535E-27F,
      -0.0135403769F,   -0.101825781F,    0.0167516917F,    -0.0844859108F,
      -0.203961149F,    -0.146854728F,    -0.0256351084F,   -0.0217358526F,
      -0.040463578F,    -0.159080878F,    -0.0173230264F,   -0.0414606258F,
      -1.37993443F,     -0.000403010839F, -0.264639258F,    -0.00162623683F,
      -0.000506186683F, -0.0971345156F,   -0.00719071226F,  -0.151655793F,
      -0.113108084F,    -5.92977449E-6F,  -0.0133371493F,   -0.133792281F,
      -0.00585484318F,  -0.69655633F,     -0.096499525F,    -0.181821153F,
      -0.0140854297F,   -0.115034528F,    -0.0567238666F,   -0.016917849F,
      -0.0116994185F,   -0.241988942F,    -0.041907452F,    -0.00749781495F,
      -0.0622495636F,   -0.129797146F,    -0.0143133979F,   -0.319103122F,
      -0.0605303682F,   -0.0988990441F,   -0.06066541F,     -0.120393537F,
      -0.162192941F,    -0.0562630147F,   -0.0808724537F,   -4.40128511E-9F,
      -0.0923685804F,   -0.329968065F,    -0.023038961F,    -0.20921576F,
      -0.823142111F,    -0.0219009239F,   -0.0918896869F,   -0.00301209372F,
      -0.000980946817F, -1.07197726F,     -0.000726169208F, -0.00974267442F,
      -0.015199679F,    -0.0937399F,      -0.0951855257F,   -0.412770838F,
      -0.127911419F,    -0.0989507511F,   -5.17859808E-5F,  -0.0283106808F,
      -1.16698644E-7F,  -0.23199214F,     -0.00841953605F,  0.0668762922F,
      -8.09454832E-6F,  -0.143220648F,    -0.134761944F,    -0.0244887508F,
      -0.278522819F,    -0.124819636F,    -2.68695283F,     -0.0175410453F,
      -0.056383837F,    -0.000200044495F, -0.000166117781F, -0.100828052F,
      -0.0248290822F,   -0.00317219947F,  -0.271724939F,    -0.0592429638F,
      -0.0179942418F,   -0.182344213F,    -0.00281497417F,  -0.0822969303F,
      -0.0709635243F,   -0.0257301573F,   -0.00266664266F,  -0.248551309F,
      -0.00790248159F,  -4.91189702E-8F,  -0.0274740849F,   0.0389145873F,
      -0.000249960198F, -0.0532691255F,   -4.48324442E-7F,  -0.0174010303F,
      -0.458671451F,    -7.46291471E-6F,  -0.304137319F,    -0.00510129705F,
      -0.420918F,       -0.187194258F,    -0.102699712F,    -0.143624604F,
      -0.00322504016F,  -0.122925311F,    -3.25353903E-6F,  -0.0277442504F,
      -0.00287824823F,  -0.00819914229F,  -0.000249197445F, 0.237226069F,
      -0.0702887F,      -0.0414888524F,   -0.149827883F,    -1.36789993E-7F,
      -0.193305701F,    -0.0903769508F,   -0.0564340279F,   1.5209862F,
      -0.205363885F,    -0.0669919625F,   -0.00685272226F,  -0.232253417F,
      -3.309484F,       -0.0744631961F,   0.00806615781F,   -0.465729356F,
      -0.22039403F,     -0.0206502452F,   -0.000213622799F, -2.17675313E-15F,
      -0.126093194F,    -0.00283362111F,  -0.0264017656F,   -0.0134308646F};
  static float t1_Weights[40000];
  static boolean_T bufferInitialized;
  __m128 r;
  float b_layerOutput[200];
  float layerOutput[200];
  float outT_f3_0_f1[200];
  float outputs_0;
  int i;
  if (!bufferInitialized) {
    readDnnConstants(&t1_Weights[0],
                     "./codegen/lib/policy_step/largeDnnConstants_1058618.bin",
                     40000);
  }
  bufferInitialized = true;
  matrixMultiply1(200, 4, 1, 128, 128, 128, &t0_Weights[0], &inputsT_0_f1[0],
                  &layerOutput[0]);
  for (i = 0; i <= 196; i += 4) {
    r = _mm_loadu_ps(&layerOutput[i]);
    _mm_storeu_ps(&layerOutput[i], _mm_add_ps(r, _mm_loadu_ps(&fv[i])));
  }
  unaryElementwise(layerOutput, outT_f3_0_f1);
  matrixMultiply1(200, 200, 1, 128, 128, 128, &t1_Weights[0], &outT_f3_0_f1[0],
                  &b_layerOutput[0]);
  for (i = 0; i <= 196; i += 4) {
    r = _mm_loadu_ps(&b_layerOutput[i]);
    _mm_storeu_ps(&b_layerOutput[i], _mm_add_ps(r, _mm_loadu_ps(&fv1[i])));
  }
  unaryElementwise(b_layerOutput, outT_f3_0_f1);
  outputs_0 = 0.0F;
  for (i = 0; i < 200; i++) {
    outputs_0 += a[i] * outT_f3_0_f1[i];
  }
  addBiasApplyActivation(&outputs_0);
  b_lambdaForColumnMajorGeneric(&outputs_0);
  return lambdaForColumnMajorGeneric(outputs_0);
}

/*
 * File trailer for callPredict.c
 *
 * [EOF]
 */
