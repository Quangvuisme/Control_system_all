/*
 * File: elementwiseOperation.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef ELEMENTWISEOPERATION_H
#define ELEMENTWISEOPERATION_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
float lambdaForColumnMajorGeneric(float X);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for elementwiseOperation.h
 *
 * [EOF]
 */
