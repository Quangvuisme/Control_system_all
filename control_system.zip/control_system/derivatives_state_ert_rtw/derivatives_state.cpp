//
// File: derivatives_state.cpp
//
// Code generated for Simulink model 'derivatives_state'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Dec 31 20:07:34 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Emulation hardware selection:
//    Differs from embedded hardware (Custom Processor->MATLAB Host Computer)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "derivatives_state.h"
#include "rtwtypes.h"

// Model step function
void derivatives_state::step()
{
  real_T u0;

  // Gain: '<S4>/Minimum sampling to time constant ratio'
  u0 = 10.0 * derivatives_state_B.Probe[0];

  // DiscreteIntegrator: '<S8>/Integrator' incorporates:
  //   Inport: '<Root>/x_in'

  if (derivatives_state_DW.Integrator_IC_LOADING != 0) {
    derivatives_state_DW.Integrator_DSTATE = derivatives_state_U.x_in;
  }

  if (derivatives_state_DW.Integrator_PrevResetState != 0) {
    derivatives_state_DW.Integrator_DSTATE = derivatives_state_U.x_in;
  }

  // MinMax: '<S4>/MinMax'
  if (!(u0 >= 0.02)) {
    u0 = 0.02;
  }

  // Product: '<S2>/1//T' incorporates:
  //   DiscreteIntegrator: '<S8>/Integrator'
  //   Inport: '<Root>/x_in'
  //   MinMax: '<S4>/MinMax'
  //   Sum: '<S2>/Sum1'

  derivatives_state_Y.x_d = 1.0 / u0 * (derivatives_state_U.x_in -
    derivatives_state_DW.Integrator_DSTATE);

  // Gain: '<S9>/Minimum sampling to time constant ratio'
  u0 = 10.0 * derivatives_state_B.Probe_j[0];

  // DiscreteIntegrator: '<S13>/Integrator' incorporates:
  //   Inport: '<Root>/q_in'

  if (derivatives_state_DW.Integrator_IC_LOADING_f != 0) {
    derivatives_state_DW.Integrator_DSTATE_o = derivatives_state_U.q_in;
  }

  if (derivatives_state_DW.Integrator_PrevResetState_p != 0) {
    derivatives_state_DW.Integrator_DSTATE_o = derivatives_state_U.q_in;
  }

  // MinMax: '<S9>/MinMax'
  if (!(u0 >= 0.02)) {
    u0 = 0.02;
  }

  // Product: '<S3>/1//T' incorporates:
  //   DiscreteIntegrator: '<S13>/Integrator'
  //   Inport: '<Root>/q_in'
  //   MinMax: '<S9>/MinMax'
  //   Sum: '<S3>/Sum1'

  derivatives_state_Y.q_d = 1.0 / u0 * (derivatives_state_U.q_in -
    derivatives_state_DW.Integrator_DSTATE_o);

  // Outport: '<Root>/x' incorporates:
  //   Inport: '<Root>/x_in'

  derivatives_state_Y.x = derivatives_state_U.x_in;

  // Outport: '<Root>/q' incorporates:
  //   Inport: '<Root>/q_in'

  derivatives_state_Y.q = derivatives_state_U.q_in;

  // Update for DiscreteIntegrator: '<S8>/Integrator'
  derivatives_state_DW.Integrator_IC_LOADING = 0U;
  derivatives_state_DW.Integrator_DSTATE += 0.001 * derivatives_state_Y.x_d;
  derivatives_state_DW.Integrator_PrevResetState = 0;

  // Update for DiscreteIntegrator: '<S13>/Integrator'
  derivatives_state_DW.Integrator_IC_LOADING_f = 0U;
  derivatives_state_DW.Integrator_DSTATE_o += 0.001 * derivatives_state_Y.q_d;
  derivatives_state_DW.Integrator_PrevResetState_p = 0;
}

// Model initialize function
void derivatives_state::initialize()
{
  // Start for Probe: '<S4>/Probe'
  derivatives_state_B.Probe[0] = 0.001;
  derivatives_state_B.Probe[1] = 0.0;

  // Start for Probe: '<S9>/Probe'
  derivatives_state_B.Probe_j[0] = 0.001;
  derivatives_state_B.Probe_j[1] = 0.0;

  // InitializeConditions for DiscreteIntegrator: '<S8>/Integrator'
  derivatives_state_DW.Integrator_IC_LOADING = 1U;

  // InitializeConditions for DiscreteIntegrator: '<S13>/Integrator'
  derivatives_state_DW.Integrator_IC_LOADING_f = 1U;
}

// Model terminate function
void derivatives_state::terminate()
{
  // (no terminate code required)
}

const char_T* derivatives_state::RT_MODEL_derivatives_state_T::getErrorStatus()
  const
{
  return (errorStatus);
}

void derivatives_state::RT_MODEL_derivatives_state_T::setErrorStatus(const
  char_T* const volatile aErrorStatus)
{
  (errorStatus = aErrorStatus);
}

// Constructor
derivatives_state::derivatives_state() :
  derivatives_state_U(),
  derivatives_state_Y(),
  derivatives_state_B(),
  derivatives_state_DW(),
  derivatives_state_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
derivatives_state::~derivatives_state()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
derivatives_state::RT_MODEL_derivatives_state_T * derivatives_state::getRTM()
{
  return (&derivatives_state_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
