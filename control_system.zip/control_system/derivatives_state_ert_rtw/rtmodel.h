//
// File: rtmodel.h
//
// Code generated for Simulink model 'derivatives_state'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Dec 31 20:07:34 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Emulation hardware selection:
//    Differs from embedded hardware (Custom Processor->MATLAB Host Computer)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef rtmodel_h_
#define rtmodel_h_
#include "derivatives_state.h"
#define MODEL_CLASSNAME                derivatives_state
#define MODEL_STEPNAME                 step

//
//  ROOT_IO_FORMAT: 0 (Individual arguments)
//  ROOT_IO_FORMAT: 1 (Structure reference)
//  ROOT_IO_FORMAT: 2 (Part of model data structure)

#define ROOT_IO_FORMAT                 1

// Macros generated for backwards compatibility
#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((void*) 0)
#endif
#endif                                 // rtmodel_h_

//
// File trailer for generated code.
//
// [EOF]
//
