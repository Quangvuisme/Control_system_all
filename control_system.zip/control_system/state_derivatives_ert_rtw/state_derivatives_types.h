//
// File: state_derivatives_types.h
//
// Code generated for Simulink model 'state_derivatives'.
//
// Model version                  : 1.2
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Fri Jan  3 16:01:24 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef state_derivatives_types_h_
#define state_derivatives_types_h_
#endif                                 // state_derivatives_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
