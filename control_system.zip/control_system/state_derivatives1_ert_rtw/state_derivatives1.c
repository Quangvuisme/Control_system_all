/*
 * File: state_derivatives1.c
 *
 * Code generated for Simulink model 'state_derivatives1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Jan  3 16:07:32 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "state_derivatives1.h"
#include "rtwtypes.h"

/* Block signals (default storage) */
B_state_derivatives1_T state_derivatives1_B;

/* Block states (default storage) */
DW_state_derivatives1_T state_derivatives1_DW;

/* External inputs (root inport signals with default storage) */
ExtU_state_derivatives1_T state_derivatives1_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_state_derivatives1_T state_derivatives1_Y;

/* Real-time model */
static RT_MODEL_state_derivatives1_T state_derivatives1_M_;
RT_MODEL_state_derivatives1_T *const state_derivatives1_M =
  &state_derivatives1_M_;

/* Model step function */
void state_derivatives1_step(void)
{
  real_T u0;

  /* Gain: '<S3>/Minimum sampling to time constant ratio' */
  u0 = 10.0 * state_derivatives1_B.Probe[0];

  /* DiscreteIntegrator: '<S7>/Integrator' incorporates:
   *  Inport: '<Root>/x_in'
   */
  if (state_derivatives1_DW.Integrator_IC_LOADING != 0) {
    state_derivatives1_DW.Integrator_DSTATE = state_derivatives1_U.x_in;
  }

  if (state_derivatives1_DW.Integrator_PrevResetState != 0) {
    state_derivatives1_DW.Integrator_DSTATE = state_derivatives1_U.x_in;
  }

  /* MinMax: '<S3>/MinMax' */
  if (!(u0 >= 0.02)) {
    u0 = 0.02;
  }

  /* Product: '<S1>/1//T' incorporates:
   *  DiscreteIntegrator: '<S7>/Integrator'
   *  Inport: '<Root>/x_in'
   *  MinMax: '<S3>/MinMax'
   *  Sum: '<S1>/Sum1'
   */
  state_derivatives1_Y.x_d = 1.0 / u0 * (state_derivatives1_U.x_in -
    state_derivatives1_DW.Integrator_DSTATE);

  /* Gain: '<S8>/Minimum sampling to time constant ratio' */
  u0 = 10.0 * state_derivatives1_B.Probe_j[0];

  /* DiscreteIntegrator: '<S12>/Integrator' incorporates:
   *  Inport: '<Root>/q_in'
   */
  if (state_derivatives1_DW.Integrator_IC_LOADING_n != 0) {
    state_derivatives1_DW.Integrator_DSTATE_b = state_derivatives1_U.q_in;
  }

  if (state_derivatives1_DW.Integrator_PrevResetState_i != 0) {
    state_derivatives1_DW.Integrator_DSTATE_b = state_derivatives1_U.q_in;
  }

  /* MinMax: '<S8>/MinMax' */
  if (!(u0 >= 0.02)) {
    u0 = 0.02;
  }

  /* Product: '<S2>/1//T' incorporates:
   *  DiscreteIntegrator: '<S12>/Integrator'
   *  Inport: '<Root>/q_in'
   *  MinMax: '<S8>/MinMax'
   *  Sum: '<S2>/Sum1'
   */
  state_derivatives1_Y.q_d = 1.0 / u0 * (state_derivatives1_U.q_in -
    state_derivatives1_DW.Integrator_DSTATE_b);

  /* Outport: '<Root>/x' incorporates:
   *  Inport: '<Root>/x_in'
   */
  state_derivatives1_Y.x = state_derivatives1_U.x_in;

  /* Outport: '<Root>/q' incorporates:
   *  Inport: '<Root>/q_in'
   */
  state_derivatives1_Y.q = state_derivatives1_U.q_in;

  /* Update for DiscreteIntegrator: '<S7>/Integrator' */
  state_derivatives1_DW.Integrator_IC_LOADING = 0U;
  state_derivatives1_DW.Integrator_DSTATE += 0.001 * state_derivatives1_Y.x_d;
  state_derivatives1_DW.Integrator_PrevResetState = 0;

  /* Update for DiscreteIntegrator: '<S12>/Integrator' */
  state_derivatives1_DW.Integrator_IC_LOADING_n = 0U;
  state_derivatives1_DW.Integrator_DSTATE_b += 0.001 * state_derivatives1_Y.q_d;
  state_derivatives1_DW.Integrator_PrevResetState_i = 0;
}

/* Model initialize function */
void state_derivatives1_initialize(void)
{
  /* Start for Probe: '<S3>/Probe' */
  state_derivatives1_B.Probe[0] = 0.001;
  state_derivatives1_B.Probe[1] = 0.0;

  /* Start for Probe: '<S8>/Probe' */
  state_derivatives1_B.Probe_j[0] = 0.001;
  state_derivatives1_B.Probe_j[1] = 0.0;

  /* InitializeConditions for DiscreteIntegrator: '<S7>/Integrator' */
  state_derivatives1_DW.Integrator_IC_LOADING = 1U;

  /* InitializeConditions for DiscreteIntegrator: '<S12>/Integrator' */
  state_derivatives1_DW.Integrator_IC_LOADING_n = 1U;
}

/* Model terminate function */
void state_derivatives1_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
