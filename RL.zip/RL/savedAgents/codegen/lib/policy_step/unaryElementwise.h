/*
 * File: unaryElementwise.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef UNARYELEMENTWISE_H
#define UNARYELEMENTWISE_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void unaryElementwise(const float X[200], float Z[200]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for unaryElementwise.h
 *
 * [EOF]
 */
