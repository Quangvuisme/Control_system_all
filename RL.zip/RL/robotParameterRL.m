clear,clc;

m = 0.116527;     % pend mass (kg)
M = 0.28;     % cart mass (kg)
L = 0.3000/2;    % pend's length from rotational hinge to center of gravity (m)
I = (1/3)*m*L^2;   % moment of inertia around center of gravity (kg.m2)
g = 9.80665;     % gravitational accel (m/s2)

% swing-up control params (main)
k_cw = 3;
k_vw = 3;
k_34=10;
angle_threshold = deg2rad(35);  % degree
uMax = 3*g;    % maximum input (m/s2)
x1_max = 0.43;% track limit (m)
x2_max = 2; % cart vel max (m/s)
E_up = m*g*L*cos(0);

% friction
kd = 0.000161;   % damping const (N.s/rad)
kdr = 0.000001; 
kt = 150;
Fc = 0.00040;

%% initial condition
init_angle = 180/180*pi;
%% Reinforcement Learning (RL) parameters
Ts = 0.02; % Agent sample time
Tf = 25;    % Simulation end time
        
