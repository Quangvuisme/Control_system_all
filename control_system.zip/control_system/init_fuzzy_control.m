clear,clc;

m = 0.116527;     % pend mass (kg)
M = 0.28;     % cart mass (kg)
L = 0.3000/2;    % pend's length from rotational hinge to center of gravity (m)
I = (1/3)*m*L^2;   % moment of inertia around center of gravity (kg.m2)
g = 9.80665;     % gravitational accel (m/s2)

% swing-up control params (main)
k_cw = 3;
k_vw = 3;
k_34=10;
angle_threshold = deg2rad(35);  % degree
uMax = 3*g;    % maximum input (m/s2)
x1_max = 0.43;% track limit (m)
x2_max = 2; % cart vel max (m/s)
E_up = m*g*L*cos(0);

% friction
kd = 0.000161;   % damping const (N.s/rad)
kdr = 0.000001; 
kt = 150;
Fc = 0.00040;
%%
init_angle = 5/180*pi;
%%
% cart pole inference system
cpFIS=mamfis( ...
    'NumInputs',4,'NumInputMFs',2, ...
    'NumOutputs',1,'NumOutputMFs',6, ...
    'AddRule','none');

%INPUT

cpFIS.Inputs(1).Name = 'Theta';
cpFIS.Inputs(1).Range = [-pi, pi];
cpFIS.Inputs(1).MembershipFunction(1).Name = 'Negative';
cpFIS.Inputs(1).MembershipFunction(1).Type = 'zmf';
cpFIS.Inputs(1).MembershipFunction(1).Parameters = [-0.5 0.5];
cpFIS.Inputs(1).MembershipFunction(2).Name = 'Positive';
cpFIS.Inputs(1).MembershipFunction(2).Type = 'smf';
cpFIS.Inputs(1).MembershipFunction(2).Parameters = [-0.5 0.5];

cpFIS.Inputs(2).Name = 'Theta_dot';
cpFIS.Inputs(2).Range = [-5,5];
cpFIS.Inputs(2).MembershipFunction(1).Name = 'Negative';
cpFIS.Inputs(2).MembershipFunction(1).Type = 'zmf';
cpFIS.Inputs(2).MembershipFunction(1).Parameters = [-5 5];
cpFIS.Inputs(2).MembershipFunction(2).Name = 'Positive';
cpFIS.Inputs(2).MembershipFunction(2).Type = 'smf';
cpFIS.Inputs(2).MembershipFunction(2).Parameters = [-5 5];

cpFIS.Inputs(3).Name = 'Cart_position';
cpFIS.Inputs(3).Range = [-2, 2];
cpFIS.Inputs(3).MembershipFunction(1).Name = 'Negative';
cpFIS.Inputs(3).MembershipFunction(1).Type = 'zmf';
cpFIS.Inputs(3).MembershipFunction(1).Parameters = [-1 1];
cpFIS.Inputs(3).MembershipFunction(2).Name = 'Positive';
cpFIS.Inputs(3).MembershipFunction(2).Type = 'smf';
cpFIS.Inputs(3).MembershipFunction(2).Parameters = [-1 1];

cpFIS.Inputs(4).Name = 'Cart_velocity';
cpFIS.Inputs(4).Range = [-1, 1];
cpFIS.Inputs(4).MembershipFunction(1).Name = 'Negative';
cpFIS.Inputs(4).MembershipFunction(1).Type = 'zmf';
cpFIS.Inputs(4).MembershipFunction(1).Parameters = [-1 1];
cpFIS.Inputs(4).MembershipFunction(2).Name = 'Positive';
cpFIS.Inputs(4).MembershipFunction(2).Type = 'smf';
cpFIS.Inputs(4).MembershipFunction(2).Parameters = [-1 1];

plotmf(cpFIS, 'input', 3, 1000);
%%
% OUTPUT

cpFIS.Outputs(1).Name = 'Accel';
cpFIS.Outputs(1).Range = [-20, 20];

cpFIS.Outputs(1).MembershipFunction(1).Name = 'NM';
cpFIS.Outputs(1).MembershipFunction(1).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(1).Parameters = [ 5, 2, -12];
cpFIS.Outputs(1).MembershipFunction(2).Name = 'PM';
cpFIS.Outputs(1).MembershipFunction(2).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(2).Parameters = [ 5, 2, 12];

cpFIS.Outputs(1).MembershipFunction(3).Name = 'NL';
cpFIS.Outputs(1).MembershipFunction(3).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(3).Parameters = [ 5, 2, -20];
cpFIS.Outputs(1).MembershipFunction(4).Name = 'PL';
cpFIS.Outputs(1).MembershipFunction(4).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(4).Parameters = [ 5, 2, 20];

cpFIS.Outputs(1).MembershipFunction(5).Name = 'NS';
cpFIS.Outputs(1).MembershipFunction(5).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(5).Parameters = [ 5, 2, -2];
cpFIS.Outputs(1).MembershipFunction(6).Name = 'PS';
cpFIS.Outputs(1).MembershipFunction(6).Type = 'gbellmf';
cpFIS.Outputs(1).MembershipFunction(6).Parameters = [ 5, 2, 2];

%plotmf(cpFIS, 'output',1 , 1000);
%%
% Specify Rules

rules= [...
    "If Theta is Negative then Accel is NM";...
    "If Theta is Positive then Accel is PM";...
    "If Theta_dot is Negative then Accel is NL";...
    "If Theta_dot is Positive then Accel is PL";...
    "If Cart_position is Negative then Accel is NS";...
    "If Cart_position is Positive then Accel is PS";...
    "If Cart_velocity is Negative then Accel is NS";...
    "If Cart_velocity is Positive then Accel is PS"];

cpFIS = addRule(cpFIS, rules);

%% open sys
mdl = "fuzzy_control.slx";
open_system(mdl);
out = sim(mdl);
%% Animatioin

% Physical Parameters  (big mass and inertia for "slow" physics)
p.m1 = 0.28;  % (kg) Cart mass
p.m2 = 0.116527;  % (kg) pole mass
p.g = 9.80665;  % (m/s^2) gravity
p.l = 0.3000;   % (m) pendulum (pole) length

% Reshape data
t = out.data_energy_LQR.Time';
data = out.data_energy_LQR.Data;
xx = data(:, 1:4)';
u_cl = data(:, 5);

% Convert states to cartesian positions:
pos = cartPolePosition(xx,p);
x1 = pos(1,:);
y1 = pos(2,:);
x2 = pos(3,:);
y2 = pos(4,:);

% Plotting parameters:
p.w = 0.4*p.l;  %Width of the cart
p.h = 0.2*p.l;  %Height of the cart
p.r = 0*p.l;  % Radius of the pendulum bob

% Compute the extents of the drawing, keeping everything in view
padding = 0.2*p.l;  %Free space around edges
xLow = -0.55;
xUpp = 0.55;
yLow = -0.35;
yUpp = 0.35;
extents = [xLow,xUpp,yLow,yUpp];

% Create and clear a figure:
figure(2); clf;
hold on;    %  <-- This is important!
set(gcf,'DoubleBuffer','on');   % Prevents flickering (maybe??)
scaleCoeff = 1.5;
fig = gcf;
fig.Position(1) = fig.Position(1) / scaleCoeff;
fig.Position(2) = fig.Position(2) / scaleCoeff;
fig.Position(3) = scaleCoeff * fig.Position(3);
fig.Position(4) = scaleCoeff * fig.Position(4);

time = 0;

plotHandles = struct;
plotHandles.railHandle = [];
plotHandles.cartHandle = [];
plotHandles.poleHandle = [];

frameLst = [];
timeLst = [];
saveGIF = 0;

tic;
while time < t(end)
    
    % Compute the position of the system at the current real world time
    posDraw = interp1(t',pos',time')';
    
    % Redraw the image
    plotHandles = drawCartPole(time, posDraw, extents, p, plotHandles);

    % create video
    frame = getframe(fig);
    frameLst = [frameLst; frame];
    timeLst = [timeLst; time];

    % Update current time
    time = toc;
end
timeLst = [timeLst; time];

if saveGIF
    filename = "LQR_cartPend.gif"; % Specify the output file name
    for idx = 1:size(frameLst)
        [A,map] = rgb2ind(frame2im(frameLst(idx,:)),256);
        if idx == 1
            imwrite(A,map,filename,"gif","LoopCount",Inf,"DelayTime",timeLst(idx+1,:)-timeLst(idx,:));
        else
            imwrite(A,map,filename,"gif","WriteMode","append","DelayTime",timeLst(idx+1,:)-timeLst(idx,:));
        end
    end
end

close Figure 2;
