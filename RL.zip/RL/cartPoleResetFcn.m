function in = cartPoleResetFcn(in)
    % Giữ con lắc ở vị trí cân bằng dưới với một chút nhiễu nhỏ
    x0 = 0;                                                   % Vị trí xe đẩy ban đầu là 0
    theta0 = pi + 0.02 * (2 * rand - 1);                      % Nhiễu nhỏ hơn để sát thực tế
    x_dot0 = 0;                                               % Vận tốc xe đẩy ban đầu là 0
    theta_dot0 = 0;                                           % Vận tốc góc ban đầu là 0

    assignin('base', 'init_angle', theta0);

    % Đặt trạng thái vào mô hình Simulink
    in = in.setVariable('x0', x0);
    in = in.setVariable('theta0', theta0);
    in = in.setVariable('x_dot0', x_dot0);
    in = in.setVariable('theta_dot0', theta_dot0);
end
