/*
 * File: elementwiseOperationInPlace.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "elementwiseOperationInPlace.h"
#include <math.h>

/* Function Definitions */
/*
 * Arguments    : float *X
 * Return Type  : void
 */
void b_lambdaForColumnMajorGeneric(float *X)
{
  *X = tanhf(*X);
}

/*
 * File trailer for elementwiseOperationInPlace.c
 *
 * [EOF]
 */
