/*
 * File: policy_step_data.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "policy_step_data.h"

/* Variable Definitions */
omp_nest_lock_t policy_step_nestLockGlobal;

boolean_T isInitialized_policy_step = false;

/*
 * File trailer for policy_step_data.c
 *
 * [EOF]
 */
