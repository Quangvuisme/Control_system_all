/*
 * File: _coder_policy_step_info.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "_coder_policy_step_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void);

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
static const mxArray *c_emlrtMexFcnResolvedFunctionsI(void)
{
  const mxArray *nameCaptureInfo;
  const char_T *data[6] = {
      "789ced585d6fd250183e98991893cdde6c17c69b25bb5bd2c84834db85718155ab1d2094"
      "0ca44b28e5303a4e7b665b0c5cb97fe04f7097fe1493f9038cf1debf"
      "61bf0e2d273929305283f64de13d6f9ef67d1ecee979680a72e2690e00b0058268ee0479"
      "33acb930df03b341e3b9306f503589fb21b249e19fc3ac61d3816327",
      "284cd580d32b7bd8d04dd574e4c9150416b431fa087b3ed2d711947503d6e345d9ab0c21"
      "064d0b0ff2c6c501d486f59101ac811d2944f1623a1f1dc6efdd00b3"
      "41e374d0f3419ff7bff0dd2cc947fa1f25f011bcdd382f1e29aaa3ea4887a301d6949aa4"
      "944ad5578aadbaf7cff105341d5b51bd2460ab887bd01d1ef086eacc",
      "eaed30f43c9a532f9da3f31ff8b9c8fdcaa5c9f770ebfd9734f948fc2dbe31a3dfbcf7db"
      "0e838fa3f0c99b825a7186655bb46b56ad691f17e47e5e8874541378"
      "927400469d56ffaf8cebe79d4781d19fa3f0b67872bee7ee42a4762d8c9d3dc5c11875f1"
      "58b19077ec7b1f2dd8adcabee10e9082b0da3bf54682857dafe78d48",
      "f7f51d753f4ed04d700bf1a12cde57c5fb8afcff2c3fd6d56f5f24f011bc2d96175db7e9"
      "0cc5d7abc3d0b32a7fb86dfe48d56fafbffdbe4d938fc4bafaed3683"
      "8fa3f067c3b7876787dd86f4416e8df2c3d2e573597c0a32bf25fd4e18fd390a5fc26ffd"
      "ef92fb6825637f0b7bdb37f3db30df2cc997f9ed6af832bf0d22f3db",
      "c5fadfd56f5f33fa7314be90df5e61a46b13254881e356fd316facca6f9f24e82678cc6f"
      "03397ca08438eebafaedcb043e822fe4b7e1ba453314ad5787a16755"
      "fef0fdd3cf74fd76bbbe9b261f8975f5db79df27140ea4eec5bb9659b93435a92fe52b67"
      "8d7eeb1f789ff0075f864514",
      ""};
  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 5744U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xEntryPoints;
  mxArray *xInputs;
  mxArray *xResult;
  const char_T *propFieldName[9] = {"Version",
                                    "ResolvedFunctions",
                                    "Checksum",
                                    "EntryPoints",
                                    "CoverageInfo",
                                    "IsPolymorphic",
                                    "PropertyList",
                                    "UUID",
                                    "ClassEntryPointIsHandle"};
  const char_T *epFieldName[8] = {
      "QualifiedName",    "NumberOfInputs", "NumberOfOutputs", "ConstantInputs",
      "ResolvedFilePath", "TimeStamp",      "Constructor",     "Visible"};
  xEntryPoints =
      emlrtCreateStructMatrix(1, 1, 8, (const char_T **)&epFieldName[0]);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "QualifiedName",
                emlrtMxCreateString("policy_step"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs",
                emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "ResolvedFilePath",
                emlrtMxCreateString(
                    "C:\\atailieuhoc\\RL\\DDPG\\savedAgents\\policy_step.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp",
                emlrtMxCreateDoubleScalar(739847.85130787035));
  emlrtSetField(xEntryPoints, 0, "Constructor",
                emlrtMxCreateLogicalScalar(false));
  emlrtSetField(xEntryPoints, 0, "Visible", emlrtMxCreateLogicalScalar(true));
  xResult =
      emlrtCreateStructMatrix(1, 1, 9, (const char_T **)&propFieldName[0]);
  emlrtSetField(xResult, 0, "Version",
                emlrtMxCreateString("24.2.0.2712019 (R2024b)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions",
                (mxArray *)c_emlrtMexFcnResolvedFunctionsI());
  emlrtSetField(xResult, 0, "Checksum",
                emlrtMxCreateString("0A2rVf35DA1K45diMzNhSB"));
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_policy_step_info.c
 *
 * [EOF]
 */
