clear,clc;

m = 0.116527;     % pend mass (kg)
M = 0.28;     % cart mass (kg)
L = 0.3000/2;    % pend's length from rotational hinge to center of gravity (m)
I = (1/3)*m*L^2;   % moment of inertia around center of gravity (kg.m2)
g = 9.80665;     % gravitational accel (m/s2)

% swing-up control params (main)
k_cw = 8;
k_vw = 5;
k_34 = 12;
angle_threshold = deg2rad(15);  % degree
uMax = 3*g;    % maximum input (m/s2)
x1_max = 6;% track limit (m)
x2_max = 2; % cart vel max (m/s)
E_up = m*g*L*cos(0);

%friction 10
% kd = 0.000161;   % damping const (N.s/rad)
% kdr = 0.000001; 
% kt = 150;
% Fc = 0.0004;

%friction 150
% kd = 0.000158;   % damping const (N.s/rad)
% kdr = 0.0000003; 
% kt = 150;
% Fc = 0.000342;

kd = 0.000158;   % damping const (N.s/rad)
kdr = 0.0000001; 
kt = 1000;
Fc = 0.000345;
%% FN filter
alpha = 0.5;
wL = 0.01;
wH = 100;
N = 5;

% Dùng chuỗi để tạo hệ phân số an toàn
G_frac = oustapp(fotf('1', '1'), -alpha, wL, wH, N);  % 1/s^alpha
G = tf(G_frac);  % Chuyển thành dạng transfer function thường

% Lấy hệ số để dùng trong Simulink
[num, den] = tfdata(G, 'v');




%% LQR, PID design
k_lqr = discrete_lqr(m, M, L, I, g, kd, kt, Fc);
plant_theta = plant_pid(m, M, L, I, g, kd, kt, Fc);
plant_x = plant_pid_x(m, M, L, I, g, kd, kt, Fc);

%% MPC design
Ts = 0.001;
PredictionHorizon = 50;
ControlHorizon = 5;

plant = plant_mpc(m,M,L,I,g,kd, kt, Fc);  % phải là tuyến tính quanh điểm cân bằng

% Đặt nhóm I/O trước khi tạo MPC object
plant.InputGroup = struct();
plant.OutputGroup = struct();
plant.InputGroup.MV = 1;         % input u
plant.OutputGroup.MO = 1:4;      % toàn bộ state là measurable

% Tạo MPC object
mpcobj = mpc(plant, Ts, PredictionHorizon, ControlHorizon);

% Giới hạn lực điều khiển
mpcobj.MV.Min = -3*g;
mpcobj.MV.Max = 3*g;

% Trọng số điều chỉnh
mpcobj.Weights.MV = 0.5;
mpcobj.Weights.MVRate = 0.1;
mpcobj.Weights.OV = [5 0.5 20 0.2 ];   % Ưu tiên giữ θ và vị trí

% Ràng buộc vị trí cart để tránh trôi xa
 % mpcobj.OV(1).Min = -0.5;  % giới hạn x không vượt ra khỏi vùng hoạt động
 % mpcobj.OV(1).Max = 0.5;




%% initial condition
init_angle = (180+10.8)/180*pi;
%init_angle = (180+20.5)/180*pi;
%init_angle = (180+148)/180*pi;

%% open sys
%mdl = "my_cart_pend.slx";
mdl = "Data_of_my_cart_pend.slx";
open_system(mdl);
out = sim(mdl);

% %% ANIMATION
% % Physical Parameters  (big mass and inertia for "slow" physics)
% p.m1 = 0.28;  % (kg) Cart mass
% p.m2 = 0.116527;  % (kg) pole mass
% p.g = 9.80665;  % (m/s^2) gravity
% p.l = 0.3000;   % (m) pendulum (pole) length
% 
% % Reshape data
% t = out.data_energy_LQR.Time';
% data = out.data_energy_LQR.Data;
% xx = data(:, 1:4)';
% u_cl = data(:, 5);
% 
% % Convert states to cartesian positions:
% pos = cartPolePosition(xx,p);
% x1 = pos(1,:);
% y1 = pos(2,:);
% x2 = pos(3,:);
% y2 = pos(4,:);
% 
% % Plotting parameters:
% p.w = 0.4*p.l;  %Width of the cart
% p.h = 0.2*p.l;  %Height of the cart
% p.r = 0*p.l;  % Radius of the pendulum bob
% 
% % Compute the extents of the drawing, keeping everything in view
% padding = 0.2*p.l;  %Free space around edges
% xLow = -0.55;
% xUpp = 0.55;
% yLow = -0.35;
% yUpp = 0.35;
% extents = [xLow,xUpp,yLow,yUpp];
% 
% % Create and clear a figure:
% figure(2); clf;
% hold on;    %  <-- This is important!
% set(gcf,'DoubleBuffer','on');   % Prevents flickering (maybe??)
% scaleCoeff = 1.5;
% fig = gcf;
% fig.Position(1) = fig.Position(1) / scaleCoeff;
% fig.Position(2) = fig.Position(2) / scaleCoeff;
% fig.Position(3) = scaleCoeff * fig.Position(3);
% fig.Position(4) = scaleCoeff * fig.Position(4);
% 
% time = 0;
% 
% plotHandles = struct;
% plotHandles.railHandle = [];
% plotHandles.cartHandle = [];
% plotHandles.poleHandle = [];
% 
% frameLst = [];
% timeLst = [];
% saveGIF = true;
% 
% tic;
% while time < t(end)
% 
%     % Compute the position of the system at the current real world time
%     posDraw = interp1(t',pos',time')';
% 
%     % Redraw the image
%     plotHandles = drawCartPole(time, posDraw, extents, p, plotHandles);
% 
%     % create video
%     frame = getframe(fig);
%     frameLst = [frameLst; frame];
%     timeLst = [timeLst; time];
% 
%     % Update current time
%     time = toc;
% end
% timeLst = [timeLst; time];
% 
% if saveGIF
%     filename = "PID_cartPend.gif"; % Specify the output file name
%     for idx = 1:size(frameLst)
%         [A,map] = rgb2ind(frame2im(frameLst(idx,:)),256);
%         if idx == 1
%             imwrite(A,map,filename,"gif","LoopCount",Inf,"DelayTime",timeLst(idx+1,:)-timeLst(idx,:));
%         else
%             imwrite(A,map,filename,"gif","WriteMode","append","DelayTime",timeLst(idx+1,:)-timeLst(idx,:));
%         end
%     end
% end
% 
% close Figure 2;