/*
 * File: PolicySystem.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "PolicySystem.h"
#include "callPredict.h"
#include "policy_step_internal_types.h"
#include <math.h>

/* Function Definitions */
/*
 * Arguments    : const c_rl_codegen_policy_rlDetermini *b_this
 *                const float varargin_1[4]
 * Return Type  : double
 */
double PolicySystem_getAction(const c_rl_codegen_policy_rlDetermini *b_this,
                              const float varargin_1[4])
{
  float dlArrayOutputs_Data;
  dlArrayOutputs_Data = predict(varargin_1);
  return fmax(fmin(dlArrayOutputs_Data, b_this->ActionBounder_.UpperLimits_[0]),
              b_this->ActionBounder_.LowerLimits_[0]);
}

/*
 * File trailer for PolicySystem.c
 *
 * [EOF]
 */
