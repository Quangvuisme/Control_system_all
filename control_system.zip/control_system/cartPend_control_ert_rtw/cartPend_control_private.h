//
// File: cartPend_control_private.h
//
// Code generated for Simulink model 'cartPend_control'.
//
// Model version                  : 1.3
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Thu Mar 20 15:07:42 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef cartPend_control_private_h_
#define cartPend_control_private_h_
#include "rtwtypes.h"
#include "cartPend_control_types.h"
#endif                                 // cartPend_control_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
