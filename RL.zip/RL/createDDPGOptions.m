    % CREATE DDPG OPTIONS FOR CART-POLE
    % - Ts: Chu kỳ lấy mẫu
    % - Tf: Thời gian tối đa của 1 episode
    % - useParallel: Bật/tắt parallel computing

    %% === DDPG Agent Options ===
    agentOptions = rlDDPGAgentOptions;
    agentOptions.SampleTime = Ts;
    agentOptions.DiscountFactor = 0.99;
    agentOptions.MiniBatchSize = 256;  % Tăng batch size để mạng học nhanh hơn
    agentOptions.ExperienceBufferLength = 1e6;  % Tăng buffer lưu trữ trải nghiệm
    agentOptions.TargetSmoothFactor = 1e-3;
    
    % Thêm noise để tăng cường exploration
    agentOptions.NoiseOptions.MeanAttractionConstant = 6; 
    agentOptions.NoiseOptions.Variance = 0.3; 
    agentOptions.NoiseOptions.VarianceDecayRate = 1e-6;

    %% === Training Options ===
    trainingOptions = rlTrainingOptions;
    trainingOptions.MaxEpisodes = 3000;  % Tăng số episode để học lâu hơn
    trainingOptions.MaxStepsPerEpisode = round(Tf / Ts);
    trainingOptions.ScoreAveragingWindowLength = 100;
    trainingOptions.StopTrainingCriteria = 'AverageReward';
    trainingOptions.StopTrainingValue = 200;  % Tăng reward dừng để đảm bảo học tốt
    trainingOptions.SaveAgentCriteria = 'EpisodeReward';
    trainingOptions.SaveAgentValue = 200;
    trainingOptions.Plots = 'training-progress';
    trainingOptions.Verbose = true;

    % Sử dụng Parallel Training nếu bật
    if useParallel
        trainingOptions.Parallelization = 'async';
        trainingOptions.ParallelizationOptions.StepsUntilDataIsSent = 64;
    end