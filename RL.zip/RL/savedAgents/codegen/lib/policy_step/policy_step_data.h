/*
 * File: policy_step_data.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef POLICY_STEP_DATA_H
#define POLICY_STEP_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern omp_nest_lock_t policy_step_nestLockGlobal;
extern boolean_T isInitialized_policy_step;

#endif
/*
 * File trailer for policy_step_data.h
 *
 * [EOF]
 */
