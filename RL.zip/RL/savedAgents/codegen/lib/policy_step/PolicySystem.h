/*
 * File: PolicySystem.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef POLICYSYSTEM_H
#define POLICYSYSTEM_H

/* Include Files */
#include "policy_step_internal_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
double PolicySystem_getAction(const c_rl_codegen_policy_rlDetermini *b_this,
                              const float varargin_1[4]);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for PolicySystem.h
 *
 * [EOF]
 */
