/*
 * File: policy_step_initialize.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "policy_step_initialize.h"
#include "policy_step.h"
#include "policy_step_data.h"
#include "omp.h"

/* Function Definitions */
/*
 * Arguments    : void
 * Return Type  : void
 */
void policy_step_initialize(void)
{
  omp_init_nest_lock(&policy_step_nestLockGlobal);
  policy_step_new();
  policy_step_init();
  isInitialized_policy_step = true;
}

/*
 * File trailer for policy_step_initialize.c
 *
 * [EOF]
 */
