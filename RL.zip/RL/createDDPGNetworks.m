    % CREATE DDPG NETWORKS FOR CART-POLE
    
    numObs = observationInfo.Dimension(1);
    numAct = actionInfo.Dimension(1);

    %% === CRITIC NETWORK ===
    criticLayerSizes = [512 256 128];

    statePath = [
        featureInputLayer(numObs, 'Normalization', 'none', 'Name', 'state')
        fullyConnectedLayer(criticLayerSizes(1), 'Name', 'CriticStateFC1')
        reluLayer('Name', 'CriticStateRelu1')
        fullyConnectedLayer(criticLayerSizes(2), 'Name', 'CriticStateFC2')
        reluLayer('Name', 'CriticStateRelu2')
        fullyConnectedLayer(criticLayerSizes(3), 'Name', 'CriticStateFC3')
    ];

    actionPath = [
        featureInputLayer(numAct, 'Normalization', 'none', 'Name', 'action')
        fullyConnectedLayer(criticLayerSizes(3), 'Name', 'CriticActionFC1')
    ];

    commonPath = [
        additionLayer(2, 'Name', 'add')
        reluLayer('Name', 'CriticCommonRelu1')
        fullyConnectedLayer(1, 'Name', 'CriticOutput')
    ];

    criticNetwork = layerGraph(statePath);
    criticNetwork = addLayers(criticNetwork, actionPath);
    criticNetwork = addLayers(criticNetwork, commonPath);
    criticNetwork = connectLayers(criticNetwork, 'CriticStateFC3', 'add/in1');
    criticNetwork = connectLayers(criticNetwork, 'CriticActionFC1', 'add/in2');

    critic = rlQValueFunction(criticNetwork, observationInfo, actionInfo);

    %% === ACTOR NETWORK ===
    actorLayerSizes = [512 256 128];

    actorNetwork = [
        featureInputLayer(numObs, 'Normalization', 'none', 'Name', 'observation')
        fullyConnectedLayer(actorLayerSizes(1), 'Name', 'ActorFC1')
        reluLayer('Name', 'ActorRelu1')
        fullyConnectedLayer(actorLayerSizes(2), 'Name', 'ActorFC2')
        reluLayer('Name', 'ActorRelu2')
        fullyConnectedLayer(actorLayerSizes(3), 'Name', 'ActorFC3')
        reluLayer('Name', 'ActorRelu3')
        fullyConnectedLayer(numAct, 'Name', 'ActorFC4')
        tanhLayer('Name', 'ActorTanh1')
    ];

    actor = rlContinuousDeterministicActor(actorNetwork, observationInfo, actionInfo);