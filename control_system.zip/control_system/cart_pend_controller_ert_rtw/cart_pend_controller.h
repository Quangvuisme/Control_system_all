//
// File: cart_pend_controller.h
//
// Code generated for Simulink model 'cart_pend_controller'.
//
// Model version                  : 5.7
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Wed Mar 19 15:15:13 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#ifndef cart_pend_controller_h_
#define cart_pend_controller_h_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include <stddef.h>

// Class declaration for model cart_pend_controller
class cart_pend_controller
{
  // public data and function members
 public:
  // External inputs (root inport signals with default storage)
  struct ExtU {
    real_T X_m[4];                     // '<Root>/X'
    real_T error[4];                   // '<Root>/error'
  };

  // Parameters (default storage)
  struct P {
    real_T E_up;                       // Variable: E_up
                                          //  Referenced by: '<S6>/Constant1'

    real_T Fc;                         // Variable: Fc
                                          //  Referenced by: '<S4>/Gain3'

    real_T I;                          // Variable: I
                                          //  Referenced by: '<S6>/Constant'

    real_T L;                          // Variable: L
                                          //  Referenced by:
                                          //    '<S4>/Gain4'
                                          //    '<S6>/Gain1'

    real_T g;                          // Variable: g
                                          //  Referenced by: '<S6>/Gain1'

    real_T k_34;                       // Variable: k_34
                                          //  Referenced by: '<S6>/Gain'

    real_T k_cw;                       // Variable: k_cw
                                          //  Referenced by: '<S5>/k_cw'

    real_T k_lqr[4];                   // Variable: k_lqr
                                          //  Referenced by: '<S2>/LQR_gain'

    real_T k_vw;                       // Variable: k_vw
                                          //  Referenced by: '<S7>/k_vw'

    real_T kd;                         // Variable: kd
                                          //  Referenced by: '<S4>/Constant'

    real_T kdr;                        // Variable: kdr
                                          //  Referenced by: '<S4>/Gain1'

    real_T kt;                         // Variable: kt
                                          //  Referenced by: '<S4>/Gain2'

    real_T m;                          // Variable: m
                                          //  Referenced by:
                                          //    '<S4>/Gain4'
                                          //    '<S6>/Constant'
                                          //    '<S6>/Gain1'

    real_T Gain_Gain;                  // Expression: -1
                                          //  Referenced by: '<S4>/Gain'

  };

  // External inputs
  ExtU rtU;

  // model initialize function
  static void initialize();

  // model step function
  static void step();

  // Constructor
  cart_pend_controller();

  // Destructor
  ~cart_pend_controller();

  // private data and function members
 private:
  // Tunable parameters
  static P rtP;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<Root>/Scope' : Unused code path elimination
//  Block '<S1>/Saturation' : Unused code path elimination
//  Block '<S1>/Reshape' : Reshape block reduction


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'cart_pend_controller'
//  '<S1>'   : 'cart_pend_controller/cartPend_control'
//  '<S2>'   : 'cart_pend_controller/cartPend_control/LQR'
//  '<S3>'   : 'cart_pend_controller/cartPend_control/energy swing up'
//  '<S4>'   : 'cart_pend_controller/cartPend_control/energy swing up/friction_cancellation'
//  '<S5>'   : 'cart_pend_controller/cartPend_control/energy swing up/position potential well'
//  '<S6>'   : 'cart_pend_controller/cartPend_control/energy swing up/pumb_energy'
//  '<S7>'   : 'cart_pend_controller/cartPend_control/energy swing up/velocity potential well'

#endif                                 // cart_pend_controller_h_

//
// File trailer for generated code.
//
// [EOF]
//
