% Plot reinforcement learning training results given filename
% Adapted for Cart-Pole System
% Copyright 2019-2025 The MathWorks, Inc.

function plotTrainingResults

%% Interactively load file
close all
[filename, pathname] = uigetfile('*.mat', 'Select Training Results File');
if isequal(filename,0)
    disp('No file selected. Exiting function.');
    return;
end

load(fullfile(pathname, filename));

% Check if trainingResults exists
if ~exist('trainingResults', 'var') || isempty(trainingResults)
    error('Invalid file: trainingResults structure is missing or empty.');
end

%% Episode reward plot
figure('Name', 'Training Results', 'NumberTitle', 'off');

subplot(3,1,1);
hold on;
if isfield(trainingResults, 'EpisodeReward')
    plot(trainingResults.EpisodeReward, 'bo-', 'LineWidth', 1.5);
end
if isfield(trainingResults, 'AverageReward')
    plot(trainingResults.AverageReward, 'r*-', 'LineWidth', 1.5);
end
if isfield(trainingResults, 'EpisodeQ0')
    plot(trainingResults.EpisodeQ0, 'gx--', 'LineWidth', 1.5);
end
legend({'Episode Reward','Average Reward','Initial Episode Value (Q0)'}, 'Location', 'NorthWest');
title('Episode Reward Plot');
xlabel('Episode Number');
ylabel('Reward');
grid on;

%% Average steps over time
subplot(3,1,2);
hold on;
if isfield(trainingResults, 'EpisodeSteps')
    plot(trainingResults.EpisodeSteps, 'bo-', 'LineWidth', 1.5);
end
if isfield(trainingResults, 'TotalAgentSteps')
    avgSteps = trainingResults.TotalAgentSteps ./ (1:numel(trainingResults.EpisodeSteps))';
    plot(avgSteps, 'r*-', 'LineWidth', 1.5);
end
legend({'Episode Steps','Average Steps'}, 'Location', 'NorthWest');
title('Average Steps per Episode');
xlabel('Episode Number');
ylabel('Steps');
grid on;

%% Episode reward vs total steps
subplot(3,1,3);
hold on;
if isfield(trainingResults, 'TotalAgentSteps') && isfield(trainingResults, 'EpisodeReward')
    plot(trainingResults.TotalAgentSteps, trainingResults.EpisodeReward, 'bo-', 'LineWidth', 1.5);
end
if isfield(trainingResults, 'TotalAgentSteps') && isfield(trainingResults, 'AverageReward')
    plot(trainingResults.TotalAgentSteps, trainingResults.AverageReward, 'r*-', 'LineWidth', 1.5);
end
if isfield(trainingResults, 'TotalAgentSteps') && isfield(trainingResults, 'EpisodeQ0')
    plot(trainingResults.TotalAgentSteps, trainingResults.EpisodeQ0, 'gx--', 'LineWidth', 1.5);
end
legend({'Episode Reward','Average Reward','Initial Episode Value (Q0)'}, 'Location', 'NorthWest');
title('Reward vs Total Steps');
xlabel('Total Steps');
ylabel('Reward');
grid on;

hold off;

