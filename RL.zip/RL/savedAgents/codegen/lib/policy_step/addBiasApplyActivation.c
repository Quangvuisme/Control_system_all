/*
 * File: addBiasApplyActivation.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "addBiasApplyActivation.h"

/* Function Definitions */
/*
 * Arguments    : float *X
 * Return Type  : void
 */
void addBiasApplyActivation(float *X)
{
  *X -= 0.386620104F;
}

/*
 * File trailer for addBiasApplyActivation.c
 *
 * [EOF]
 */
