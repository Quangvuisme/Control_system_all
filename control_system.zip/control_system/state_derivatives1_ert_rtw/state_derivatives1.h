/*
 * File: state_derivatives1.h
 *
 * Code generated for Simulink model 'state_derivatives1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
 * C/C++ source code generated on : Fri Jan  3 16:07:32 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef state_derivatives1_h_
#define state_derivatives1_h_
#ifndef state_derivatives1_COMMON_INCLUDES_
#define state_derivatives1_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* state_derivatives1_COMMON_INCLUDES_ */

#include <stddef.h>
#include "state_derivatives1_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Probe[2];                     /* '<S3>/Probe' */
  real_T Probe_j[2];                   /* '<S8>/Probe' */
} B_state_derivatives1_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T Integrator_DSTATE;            /* '<S7>/Integrator' */
  real_T Integrator_DSTATE_b;          /* '<S12>/Integrator' */
  int8_T Integrator_PrevResetState;    /* '<S7>/Integrator' */
  int8_T Integrator_PrevResetState_i;  /* '<S12>/Integrator' */
  uint8_T Integrator_IC_LOADING;       /* '<S7>/Integrator' */
  uint8_T Integrator_IC_LOADING_n;     /* '<S12>/Integrator' */
} DW_state_derivatives1_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T x_in;                         /* '<Root>/x_in' */
  real_T q_in;                         /* '<Root>/q_in' */
} ExtU_state_derivatives1_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T x;                            /* '<Root>/x' */
  real_T x_d;                          /* '<Root>/x_d' */
  real_T q;                            /* '<Root>/q' */
  real_T q_d;                          /* '<Root>/q_d' */
} ExtY_state_derivatives1_T;

/* Real-time Model Data Structure */
struct tag_RTM_state_derivatives1_T {
  const char_T * volatile errorStatus;
};

/* Block signals (default storage) */
extern B_state_derivatives1_T state_derivatives1_B;

/* Block states (default storage) */
extern DW_state_derivatives1_T state_derivatives1_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_state_derivatives1_T state_derivatives1_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_state_derivatives1_T state_derivatives1_Y;

/* Model entry point functions */
extern void state_derivatives1_initialize(void);
extern void state_derivatives1_step(void);
extern void state_derivatives1_terminate(void);

/* Real-time Model object */
extern RT_MODEL_state_derivatives1_T *const state_derivatives1_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Gain' : Eliminated nontunable gain of 1
 * Block '<S7>/Saturation' : Eliminated Saturate block
 * Block '<S1>/[A,B]' : Eliminated Saturate block
 * Block '<S2>/Gain' : Eliminated nontunable gain of 1
 * Block '<S12>/Saturation' : Eliminated Saturate block
 * Block '<S2>/[A,B]' : Eliminated Saturate block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'state_derivatives1'
 * '<S1>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)'
 * '<S2>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1'
 * '<S3>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)/Enable//disable time constant'
 * '<S4>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)/Initialization'
 * '<S5>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)/Integrator (Discrete or Continuous)'
 * '<S6>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)/Initialization/Init_u'
 * '<S7>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)/Integrator (Discrete or Continuous)/Discrete'
 * '<S8>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1/Enable//disable time constant'
 * '<S9>'   : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1/Initialization'
 * '<S10>'  : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1/Integrator (Discrete or Continuous)'
 * '<S11>'  : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1/Initialization/Init_u'
 * '<S12>'  : 'state_derivatives1/Filtered Derivative (Discrete or Continuous)1/Integrator (Discrete or Continuous)/Discrete'
 */
#endif                                 /* state_derivatives1_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
