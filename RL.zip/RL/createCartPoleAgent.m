% Cart-Pole -- DDPG Agent Training Script
% Adapted from Walking Robot Example
% Copyright 2019-2025 The MathWorks, Inc.

%% SET UP ENVIRONMENT
% Speedup options
useFastRestart = true;
useGPU = true;      % Cart-Pole không cần GPU
useParallel = true; % Không cần parallel training

% Create the observation info
numObs = 4; % Cart-Pole có 4 đầu vào: [x, x_dot, theta, theta_dot]
observationInfo = rlNumericSpec([numObs 1]);
observationInfo.Name = 'observations';

% Create the action info
numAct = 1; % Cart-Pole có 1 đầu ra: lực tác động lên xe đẩy
actionInfo = rlNumericSpec([numAct 1], 'LowerLimit', -pi*3, 'UpperLimit', pi*3);
actionInfo.Name = 'cart_force';

% Environment
mdl = 'cartPoleRL'; % Mô hình Simulink cho Cart-Pole
load_system(mdl);
blk = [mdl, '/RL Agent'];
env = rlSimulinkEnv(mdl, blk, observationInfo, actionInfo);
env.ResetFcn = @(in)cartPoleResetFcn(in);

if ~useFastRestart
    env.UseFastRestart = 'on';
end

%% CREATE NEURAL NETWORKS
createDDPGNetworks; % Tạo mạng nơ-ron cho Actor & Critic

%% CREATE AND TRAIN AGENT
createDDPGOptions; % Thiết lập tham số DDPG
agent = rlDDPGAgent(actor, critic, agentOptions);
trainingResults = train(agent, env, trainingOptions);

%% SAVE AGENT
reset(agent); % Clears the experience buffer
curDir = pwd;
saveDir = 'savedAgents';
if ~exist(saveDir, 'dir')
    mkdir(saveDir);
end
cd(saveDir);
save(['trainedAgent_CartPole_' datestr(now, 'mm_DD_YYYY_HHMM')], 'agent');
save(['trainingResults_CartPole_' datestr(now, 'mm_DD_YYYY_HHMM')], 'trainingResults');
cd(curDir);
