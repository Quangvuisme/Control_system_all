/*
 * File: policy_step.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef POLICY_STEP_H
#define POLICY_STEP_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern double policy_step(const float observation1[4]);

void policy_step_delete(void);

void policy_step_init(void);

void policy_step_new(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for policy_step.h
 *
 * [EOF]
 */
