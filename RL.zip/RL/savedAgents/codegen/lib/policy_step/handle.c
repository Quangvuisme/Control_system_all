/*
 * File: handle.c
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

/* Include Files */
#include "handle.h"
#include "policy_step_internal_types.h"

/* Function Definitions */
/*
 * Arguments    : c_rl_codegen_policy_rlDetermini *obj
 * Return Type  : void
 */
void b_handle_matlabCodegenDestructo(c_rl_codegen_policy_rlDetermini *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    if (obj->isInitialized == 1) {
      obj->isInitialized = 2;
    }
  }
}

/*
 * Arguments    : rl_codegen_model_DLNetworkModel *obj
 * Return Type  : void
 */
void handle_matlabCodegenDestructor(rl_codegen_model_DLNetworkModel *obj)
{
  if (!obj->matlabCodegenIsDeleted) {
    obj->matlabCodegenIsDeleted = true;
    if (obj->isInitialized == 1) {
      obj->isInitialized = 2;
    }
  }
}

/*
 * File trailer for handle.c
 *
 * [EOF]
 */
