function u = f_lqr_controller(e)
% Fractional LQR controller function (state feedback)
% Input:  e - state error vector [x; dx; theta; dtheta]
% Output: u - control signal (cart acceleration)

% System parameters
m = 0.116527;
M = 0.28;
L = 0.3000 / 2;
I = (1/3) * m * L^2;
g = 9.80665;
kd = 0.01;

% Linearized A, B matrices
A = zeros(4);
A(1,2) = 1;
A(3,4) = 1;
A(4,3) = m * g * L / (m * L^2 + I);
A(4,4) = -kd / (m * L^2 + I);

B = zeros(4,1);
B(2) = 1;
B(4) = -m * L / (m * L^2 + I);

Q = diag([10, 1, 10, 1]);
R = 0.001;

persistent lambda_prev h alpha

% Initialize persistent variables
if isempty(lambda_prev)
    lambda_prev = zeros(4,1);
    h = 0.001;         % Time step
    alpha = 0.9;       % Fractional order
end

% Calculate lambda update (backward Euler approx for D^alpha lambda)
lambda_dot = -A' * lambda_prev - Q * e;
lambda = h^alpha * lambda_dot + lambda_prev;

% Control law: u = -R^{-1} * B' * lambda
u = -R \ (B' * lambda);

% Update persistent state
lambda_prev = lambda;
end
