//
// File: cart_pend_controller.cpp
//
// Code generated for Simulink model 'cart_pend_controller'.
//
// Model version                  : 5.7
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Wed Mar 19 15:15:13 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "cart_pend_controller.h"

// Model step function
void cart_pend_controller::step()
{
  // (no output/update code required)
}

// Model initialize function
void cart_pend_controller::initialize()
{
  // (no initialization code required)
}

// Constructor
cart_pend_controller::cart_pend_controller():
  rtU()
{
  // Currently there is no constructor body generated.
}

// Destructor
cart_pend_controller::~cart_pend_controller()
{
  // Currently there is no destructor body generated.
}

//
// File trailer for generated code.
//
// [EOF]
//
