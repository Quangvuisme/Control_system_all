/*
 * File: _coder_policy_step_info.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef _CODER_POLICY_STEP_INFO_H
#define _CODER_POLICY_STEP_INFO_H

/* Include Files */
#include "mex.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus
}
#endif

#endif
/*
 * File trailer for _coder_policy_step_info.h
 *
 * [EOF]
 */
