/*
 * File: policy_step_internal_types.h
 *
 * MATLAB Coder version            : 24.2
 * C/C++ source code generated on  : 18-Aug-2025 20:27:20
 */

#ifndef POLICY_STEP_INTERNAL_TYPES_H
#define POLICY_STEP_INTERNAL_TYPES_H

/* Include Files */
#include "policy_step_types.h"
#include "rtwtypes.h"

/* Type Definitions */
#ifndef c_typedef_rl_codegen_model_DLNe
#define c_typedef_rl_codegen_model_DLNe
typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
} rl_codegen_model_DLNetworkModel;
#endif /* c_typedef_rl_codegen_model_DLNe */

#ifndef c_typedef_c_rl_codegen_policy_i
#define c_typedef_c_rl_codegen_policy_i
typedef struct {
  double UpperLimits_[1];
  double LowerLimits_[1];
} c_rl_codegen_policy_internal_Sa;
#endif /* c_typedef_c_rl_codegen_policy_i */

#ifndef c_typedef_c_rl_codegen_policy_r
#define c_typedef_c_rl_codegen_policy_r
typedef struct {
  boolean_T matlabCodegenIsDeleted;
  int isInitialized;
  boolean_T isSetupComplete;
  rl_codegen_model_DLNetworkModel *Model_;
  c_rl_codegen_policy_internal_Sa ActionBounder_;
} c_rl_codegen_policy_rlDetermini;
#endif /* c_typedef_c_rl_codegen_policy_r */

#endif
/*
 * File trailer for policy_step_internal_types.h
 *
 * [EOF]
 */
