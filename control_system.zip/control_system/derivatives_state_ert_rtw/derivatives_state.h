//
// File: derivatives_state.h
//
// Code generated for Simulink model 'derivatives_state'.
//
// Model version                  : 1.1
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Tue Dec 31 20:07:34 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Emulation hardware selection:
//    Differs from embedded hardware (Custom Processor->MATLAB Host Computer)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef derivatives_state_h_
#define derivatives_state_h_
#include "rtwtypes.h"
#include <stddef.h>
#include "derivatives_state_types.h"

// Class declaration for model derivatives_state
class derivatives_state
{
  // public data and function members
 public:
  // Block signals (default storage)
  struct B_derivatives_state_T {
    real_T Probe[2];                   // '<S4>/Probe'
    real_T Probe_j[2];                 // '<S9>/Probe'
  };

  // Block states (default storage) for system '<Root>'
  struct DW_derivatives_state_T {
    real_T Integrator_DSTATE;          // '<S8>/Integrator'
    real_T Integrator_DSTATE_o;        // '<S13>/Integrator'
    int8_T Integrator_PrevResetState;  // '<S8>/Integrator'
    int8_T Integrator_PrevResetState_p;// '<S13>/Integrator'
    uint8_T Integrator_IC_LOADING;     // '<S8>/Integrator'
    uint8_T Integrator_IC_LOADING_f;   // '<S13>/Integrator'
  };

  // External inputs (root inport signals with default storage)
  struct ExtU_derivatives_state_T {
    real_T x_in;                       // '<Root>/x_in'
    real_T q_in;                       // '<Root>/q_in'
  };

  // External outputs (root outports fed by signals with default storage)
  struct ExtY_derivatives_state_T {
    real_T x;                          // '<Root>/x'
    real_T x_d;                        // '<Root>/x_d'
    real_T q;                          // '<Root>/q'
    real_T q_d;                        // '<Root>/q_d'
  };

  // Real-time Model Data Structure
  struct RT_MODEL_derivatives_state_T {
    const char_T * volatile errorStatus;
    const char_T* getErrorStatus() const;
    void setErrorStatus(const char_T* const volatile aErrorStatus);
  };

  // Real-Time Model get method
  derivatives_state::RT_MODEL_derivatives_state_T * getRTM();

  // Root inports set method
  void setExternalInputs(const ExtU_derivatives_state_T
    *pExtU_derivatives_state_T)
  {
    derivatives_state_U = *pExtU_derivatives_state_T;
  }

  // Root outports get method
  const ExtY_derivatives_state_T &getExternalOutputs() const
  {
    return derivatives_state_Y;
  }

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  static void terminate();

  // Constructor
  derivatives_state();

  // Destructor
  ~derivatives_state();

  // private data and function members
 private:
  // External inputs
  ExtU_derivatives_state_T derivatives_state_U;

  // External outputs
  ExtY_derivatives_state_T derivatives_state_Y;

  // Block signals
  B_derivatives_state_T derivatives_state_B;

  // Block states
  DW_derivatives_state_T derivatives_state_DW;

  // Real-Time Model
  RT_MODEL_derivatives_state_T derivatives_state_M;
};

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S2>/Gain' : Eliminated nontunable gain of 1
//  Block '<S8>/Saturation' : Eliminated Saturate block
//  Block '<S2>/[A,B]' : Eliminated Saturate block
//  Block '<S3>/Gain' : Eliminated nontunable gain of 1
//  Block '<S13>/Saturation' : Eliminated Saturate block
//  Block '<S3>/[A,B]' : Eliminated Saturate block


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'derivatives_state'
//  '<S1>'   : 'derivatives_state/state_derivatives'
//  '<S2>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)'
//  '<S3>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1'
//  '<S4>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)/Enable//disable time constant'
//  '<S5>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)/Initialization'
//  '<S6>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)/Integrator (Discrete or Continuous)'
//  '<S7>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)/Initialization/Init_u'
//  '<S8>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)/Integrator (Discrete or Continuous)/Discrete'
//  '<S9>'   : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1/Enable//disable time constant'
//  '<S10>'  : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1/Initialization'
//  '<S11>'  : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1/Integrator (Discrete or Continuous)'
//  '<S12>'  : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1/Initialization/Init_u'
//  '<S13>'  : 'derivatives_state/state_derivatives/Filtered Derivative (Discrete or Continuous)1/Integrator (Discrete or Continuous)/Discrete'

#endif                                 // derivatives_state_h_

//
// File trailer for generated code.
//
// [EOF]
//
