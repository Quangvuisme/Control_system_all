//
// File: cart_pend_controller_data.cpp
//
// Code generated for Simulink model 'cart_pend_controller'.
//
// Model version                  : 5.7
// Simulink Coder version         : 24.2 (R2024b) 21-Jun-2024
// C/C++ source code generated on : Wed Mar 19 15:15:13 2025
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex-M
// Code generation objectives:
//    1. Execution efficiency
//    2. RAM efficiency
// Validation result: Not run
//
#include "cart_pend_controller.h"

// Block parameters (default storage)
cart_pend_controller::P cart_pend_controller::rtP = {
  // Variable: E_up
  //  Referenced by: '<S6>/Constant1'

  0.1714109256825,

  // Variable: Fc
  //  Referenced by: '<S4>/Gain3'

  0.0004,

  // Variable: I
  //  Referenced by: '<S6>/Constant'

  0.0008739525,

  // Variable: L
  //  Referenced by:
  //    '<S4>/Gain4'
  //    '<S6>/Gain1'

  0.15,

  // Variable: g
  //  Referenced by: '<S6>/Gain1'

  9.80665,

  // Variable: k_34
  //  Referenced by: '<S6>/Gain'

  8.0,

  // Variable: k_cw
  //  Referenced by: '<S5>/k_cw'

  3.0,

  // Variable: k_lqr
  //  Referenced by: '<S2>/LQR_gain'

  { -6.3245553203367546, -6.22736737402048, -39.096951227260774,
    -5.3775130716616628 },

  // Variable: k_vw
  //  Referenced by: '<S7>/k_vw'

  3.0,

  // Variable: kd
  //  Referenced by: '<S4>/Constant'

  0.000161,

  // Variable: kdr
  //  Referenced by: '<S4>/Gain1'

  1.0E-6,

  // Variable: kt
  //  Referenced by: '<S4>/Gain2'

  150.0,

  // Variable: m
  //  Referenced by:
  //    '<S4>/Gain4'
  //    '<S6>/Constant'
  //    '<S6>/Gain1'

  0.116527,

  // Expression: -1
  //  Referenced by: '<S4>/Gain'

  -1.0
};

//
// File trailer for generated code.
//
// [EOF]
//
